//! JNI 导出函数
//!
//! 对应 Kotlin 侧 `com.branchbase.core.RustBridge` 的 `external fun` 声明。
//! 函数命名遵循 JNI 规范：`Java_<包名>_<类名>_<方法名>`。
//!
//! 约定：返回 JSON 字符串；出错时返回空字符串（Kotlin 侧判空处理）。

use jni::objects::{JClass, JString};
use jni::sys::{jboolean, jint, jstring};
use jni::JNIEnv;
use std::future::Future;
use std::sync::OnceLock;

use crate::auth::oauth::{OAuthClient, PkcePair};
use crate::auth::twofactor::TwoFactorVerifier;
use crate::error::CoreError;
use crate::models::OAuthConfig;

/// 全局 tokio runtime（复用，避免反复创建）
fn runtime() -> &'static tokio::runtime::Runtime {
    static RT: OnceLock<tokio::runtime::Runtime> = OnceLock::new();
    RT.get_or_init(|| tokio::runtime::Runtime::new().expect("创建 tokio runtime 失败"))
}

/// 阻塞执行异步任务
fn block_on<F: Future>(f: F) -> F::Output {
    runtime().block_on(f)
}

/// 从 JString 提取 Rust String
fn jstr(env: &mut JNIEnv, s: &JString) -> String {
    env.get_string(s)
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_default()
}

/// 将 Result<String> 转为 JString（失败返回 "ERROR:..." 前缀，供 Kotlin 区分）
fn into_jstring(env: &mut JNIEnv, r: crate::error::Result<String>) -> jstring {
    match r {
        Ok(s) => env.new_string(s).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut()),
        Err(e) => env
            .new_string(format!("ERROR:{e}"))
            .map(|s| s.into_raw())
            .unwrap_or(std::ptr::null_mut()),
    }
}

/// 返回核心库版本号
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCoreVersion<'local>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    env.new_string(crate::CORE_VERSION)
        .map(|s| s.into_raw())
        .unwrap_or(std::ptr::null_mut())
}

/// 生成 PKCE 参数（返回 JSON: {"verifier": "...", "challenge": "..."}）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGeneratePkce<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    let pair = PkcePair::generate();
    let json = serde_json::json!({
        "verifier": pair.verifier,
        "challenge": pair.challenge,
    });
    into_jstring(&mut env, serde_json::to_string(&json).map_err(CoreError::from))
}

/// 构建 OAuth 授权 URL
/// 参数：clientId, redirectUri, host, scopes(空格分隔)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeBuildAuthorizeUrl<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    client_id: JString<'local>,
    redirect_uri: JString<'local>,
    host: JString<'local>,
    scopes: JString<'local>,
    challenge: JString<'local>,
) -> jstring {
    let config = OAuthConfig {
        client_id: jstr(&mut env, &client_id),
        client_secret: String::new(),
        redirect_uri: jstr(&mut env, &redirect_uri),
        host: jstr(&mut env, &host),
        scopes: jstr(&mut env, &scopes)
            .split_whitespace()
            .map(|s| s.to_string())
            .collect(),
    };
    let challenge = jstr(&mut env, &challenge);
    let client = OAuthClient::new(config);
    into_jstring(&mut env, client.authorize_url(&challenge))
}

/// 用授权码交换 token，返回 Session JSON
/// 参数：clientId, redirectUri, host, code, verifier
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeExchangeCode<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    client_id: JString<'local>,
    client_secret: JString<'local>,
    redirect_uri: JString<'local>,
    host: JString<'local>,
    code: JString<'local>,
    verifier: JString<'local>,
) -> jstring {
    let config = OAuthConfig {
        client_id: jstr(&mut env, &client_id),
        client_secret: jstr(&mut env, &client_secret),
        redirect_uri: jstr(&mut env, &redirect_uri),
        host: jstr(&mut env, &host),
        scopes: vec![],
    };
    let client = OAuthClient::new(config);
    let code = jstr(&mut env, &code);
    let verifier = jstr(&mut env, &verifier);

    let result: crate::error::Result<String> = block_on(async move {
        let session = client.exchange_code(&code, &verifier).await?;
        serde_json::to_string(&session).map_err(CoreError::from)
    });

    into_jstring(&mut env, result)
}

/// 获取当前用户信息（返回 User JSON）
/// 参数：host, accessToken
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetCurrentUser<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        let user = crate::api::GitHubApi::new(client).me().await?;
        serde_json::to_string(&user).map_err(CoreError::from)
    });

    into_jstring(&mut env, result)
}

/// 获取当前用户仓库列表（返回 Repository 数组 JSON）
/// 参数：host, accessToken
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetMyRepos<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        let repos = crate::api::GitHubApi::new(client).my_repos().await?;
        serde_json::to_string(&repos).map_err(CoreError::from)
    });

    into_jstring(&mut env, result)
}

/// 获取当前用户星标的仓库（返回 Repository 数组 JSON）
/// 参数：host, accessToken
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetStarredRepos<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        let repos = crate::api::GitHubApi::new(client).starred_repos().await?;
        serde_json::to_string(&repos).map_err(CoreError::from)
    });

    into_jstring(&mut env, result)
}

/// 获取当前用户软件包（返回 Package 数组 JSON）
/// 参数：host, accessToken
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetMyPackages<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        let packages = crate::api::GitHubApi::new(client).my_packages().await?;
        serde_json::to_string(&packages).map_err(CoreError::from)
    });

    into_jstring(&mut env, result)
}

/// 获取当前用户项目（返回 Project 数组 JSON）
/// 参数：host, accessToken
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetMyProjects<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        let projects = crate::api::GitHubApi::new(client).my_projects().await?;
        serde_json::to_string(&projects).map_err(CoreError::from)
    });

    into_jstring(&mut env, result)
}

/// 获取用户收到的事件（返回原始 JSON 数组）
/// 参数：host, accessToken, login
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetReceivedEvents<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    login: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let login = jstr(&mut env, &login);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).received_events(&login).await
    });

    into_jstring(&mut env, result)
}

/// 搜索仓库（返回原始 JSON 含 total_count + items）
/// 参数：host, accessToken, query, sort(可空)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeSearchRepositories<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    query: JString<'local>,
    sort: JString<'local>,
    page: jint,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let query = jstr(&mut env, &query);
    let sort = jstr(&mut env, &sort);
    let page = page.max(1) as u32;
    let sort_opt = if sort.is_empty() { None } else { Some(sort.as_str()) };

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).search_repositories(&query, sort_opt, page).await
    });

    into_jstring(&mut env, result)
}

/// 搜索用户（返回原始 JSON）
/// 参数：host, accessToken, query
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeSearchUsers<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    query: JString<'local>,
    page: jint,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let query = jstr(&mut env, &query);
    let page = page.max(1) as u32;

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).search_users(&query, page).await
    });

    into_jstring(&mut env, result)
}

/// 搜索 issues/PR（返回原始 JSON）
/// 参数：host, accessToken, query
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeSearchIssues<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    query: JString<'local>,
    page: jint,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let query = jstr(&mut env, &query);
    let page = page.max(1) as u32;

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).search_issues(&query, page).await
    });

    into_jstring(&mut env, result)
}

/// 搜索代码（返回原始 JSON，含 text_matches）
/// 参数：host, accessToken, query
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeSearchCode<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    query: JString<'local>,
    page: jint,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let query = jstr(&mut env, &query);
    let page = page.max(1) as u32;

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).search_code(&query, page).await
    });

    into_jstring(&mut env, result)
}

/// 搜索提交（返回原始 JSON 含 total_count + items）
/// 参数：host, accessToken, query
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeSearchCommits<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    query: JString<'local>,
    page: jint,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let query = jstr(&mut env, &query);
    let page = page.max(1) as u32;

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).search_commits(&query, page).await
    });

    into_jstring(&mut env, result)
}

/// 搜索主题（返回原始 JSON 含 total_count + items）
/// 参数：host, accessToken, query
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeSearchTopics<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    query: JString<'local>,
    page: jint,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let query = jstr(&mut env, &query);
    let page = page.max(1) as u32;

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).search_topics(&query, page).await
    });

    into_jstring(&mut env, result)
}

/// 校验 2FA 验证码格式（返回 "1" 表示有效，"0" 表示无效）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeValidateTwoFactor<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    code: JString<'local>,
) -> jstring {
    let code = jstr(&mut env, &code);
    let valid = TwoFactorVerifier::validate_format(&code).is_ok();
    let out = if valid { "1" } else { "0" };
    env.new_string(out).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}

/// 用 refresh token 刷新 access token（返回新 Token JSON）
/// 参数：clientId, clientSecret, host, refreshToken
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeRefreshToken<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    client_id: JString<'local>,
    client_secret: JString<'local>,
    host: JString<'local>,
    refresh_token: JString<'local>,
) -> jstring {
    let config = OAuthConfig {
        client_id: jstr(&mut env, &client_id),
        client_secret: jstr(&mut env, &client_secret),
        redirect_uri: String::new(),
        host: jstr(&mut env, &host),
        scopes: vec![],
    };
    let client = OAuthClient::new(config);
    let refresh_token = jstr(&mut env, &refresh_token);

    let result: crate::error::Result<String> = block_on(async move {
        let token = client.refresh_token(&refresh_token).await?;
        serde_json::to_string(&token).map_err(CoreError::from)
    });

    into_jstring(&mut env, result)
}

// ── HTML 解析与跳转导航 ────────────────────────────────────

use crate::html::{resolve_link, ResolveContext};

/// 从 JString 参数构建链接解析上下文。
fn resolve_ctx(
    env: &mut JNIEnv,
    host: &JString,
    owner: &JString,
    repo: &JString,
    branch: &JString,
    base_dir: &JString,
    current_user: &JString,
) -> ResolveContext {
    ResolveContext {
        host: jstr(env, host),
        owner: jstr(env, owner),
        repo: jstr(env, repo),
        branch: jstr(env, branch),
        base_dir: jstr(env, base_dir),
        current_user: jstr(env, current_user),
    }
}

/// 解析单个链接为内部跳转目标（返回 Destination JSON）
/// 参数：url, host, owner, repo, branch, baseDir, currentUser
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeResolveLink<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    url: JString<'local>,
    host: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    branch: JString<'local>,
    base_dir: JString<'local>,
    current_user: JString<'local>,
) -> jstring {
    let url = jstr(&mut env, &url);
    let ctx = resolve_ctx(&mut env, &host, &owner, &repo, &branch, &base_dir, &current_user);
    let dest = resolve_link(&url, &ctx);
    into_jstring(
        &mut env,
        serde_json::to_string(&dest).map_err(CoreError::from),
    )
}

/// 获取仓库 README 渲染 HTML（返回 HTML 字符串）
/// 参数：host, accessToken, owner, repo, branch（空串=默认分支）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeReadmeHtml<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    branch: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let branch = jstr(&mut env, &branch);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).readme_html(&owner, &repo, &branch).await
    });

    into_jstring(&mut env, result)
}

/// 获取仓库分支列表（返回 Branch 数组 JSON）
/// 参数：host, accessToken, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeListBranches<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        let branches = crate::api::GitHubApi::new(client).list_branches(&owner, &repo).await?;
        serde_json::to_string(&branches).map_err(CoreError::from)
    });

    into_jstring(&mut env, result)
}

/// 获取单个仓库信息（返回原始 JSON）
/// 参数：host, accessToken, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetRepoInfo<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).repo_info(&owner, &repo).await
    });

    into_jstring(&mut env, result)
}

/// 获取仓库语言统计（返回 {语言:字节数} JSON）
/// 参数：host, accessToken, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetRepoLanguages<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).repo_languages(&owner, &repo).await
    });

    into_jstring(&mut env, result)
}

/// 获取仓库贡献者（返回 JSON 数组）
/// 参数：host, accessToken, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetRepoContributors<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).repo_contributors(&owner, &repo).await
    });

    into_jstring(&mut env, result)
}

/// 通用 GET（列表等任意路径，返回原始 JSON）
/// 参数：host, accessToken, path（如 "/repos/{o}/{r}/issues?state=open"）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetJson<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    path: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let path = jstr(&mut env, &path);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        client.get_json(&path).await
    });

    into_jstring(&mut env, result)
}

/// 关闭/重新打开 issue 并指定原因（返回原始 JSON）
/// 参数：host, token, owner, repo, number, state（open / closed）, stateReason（completed / not_planned / 空串）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeUpdateIssueState<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    number: JString<'local>,
    state: JString<'local>,
    state_reason: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let number = jstr(&mut env, &number);
    let state = jstr(&mut env, &state);
    let state_reason = jstr(&mut env, &state_reason);
    let result: crate::error::Result<String> = block_on(async move {
        let n: u64 = number.parse().unwrap_or(0);
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .update_issue_state(&owner, &repo, n, &state, &state_reason)
            .await
    });
    into_jstring(&mut env, result)
}

/// 通用 GET（自定义 Accept）：timeline 等端点需要特定 media type
/// 参数：host, token, path, accept
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetJsonAccept<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    path: JString<'local>,
    accept: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let path = jstr(&mut env, &path);
    let accept = jstr(&mut env, &accept);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).get_json_accept(&path, &accept).await
    });
    into_jstring(&mut env, result)
}

/// 沉浸式翻译：翻译一段文本（原文 + 译文对照用）
///
/// 参数：text, fromLang（如 en）, toLang（如 zh-CN）, optionsJson
///   optionsJson = `{"provider":"mymemory|deepseek","apiKey":"…","model":"…","baseUrl":"…"}`
///   —— 用 JSON 而不是继续加形参：后端选项以后还会长（提示词、术语表、超时），
///   这里加字段不用再动 JNI 签名。字段缺失/JSON 损坏都会退化成默认后端，不会失败。
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeTranslate<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    text: JString<'local>,
    from: JString<'local>,
    to: JString<'local>,
    options: JString<'local>,
) -> jstring {
    let text = jstr(&mut env, &text);
    let from = jstr(&mut env, &from);
    let to = jstr(&mut env, &to);
    let options = jstr(&mut env, &options);
    let result: crate::error::Result<String> = block_on(async move {
        let options = crate::translate::Options::parse(&options);
        crate::translate::translate(&text, &from, &to, &options).await
    });
    into_jstring(&mut env, result)
}

/// 通用 PATCH（返回原始 JSON）：编辑评论正文 / 勾选任务清单等
/// 参数：host, token, path, bodyJson
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativePatchJson<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    path: JString<'local>,
    body: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let path = jstr(&mut env, &path);
    let body = jstr(&mut env, &body);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).patch_json(&path, &body).await
    });
    into_jstring(&mut env, result)
}

/// 通用 DELETE（返回原始 JSON）：用于「取消反应」等需要撤回的操作
/// 参数：host, token, path
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeDeleteJson<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    path: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let path = jstr(&mut env, &path);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).delete_json(&path).await
    });
    into_jstring(&mut env, result)
}

/// 通用 POST（返回原始 JSON）：用于 reactions 等没有专门封装的小接口
/// 参数：host, token, path, bodyJson
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativePostJson<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    path: JString<'local>,
    body: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let path = jstr(&mut env, &path);
    let body = jstr(&mut env, &body);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).post_json(&path, &body).await
    });
    into_jstring(&mut env, result)
}

/// 通用 GraphQL 查询（返回 `data` 部分 JSON）
/// 参数：host, accessToken, query, variablesJson（JSON 对象字符串，空串 = {}）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGraphQL<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    query: JString<'local>,
    variables: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let query = jstr(&mut env, &query);
    let variables = jstr(&mut env, &variables);

    let result: crate::error::Result<String> = block_on(async move {
        let vars: serde_json::Value = if variables.trim().is_empty() {
            serde_json::json!({})
        } else {
            serde_json::from_str(&variables)?
        };
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GraphQLApi::new(client).query(&query, vars).await
    });

    into_jstring(&mut env, result)
}

/// 贡献日历（GraphQL `contributionsCollection.contributionCalendar`，52 周）
/// 参数：host, accessToken, login, from(ISO8601), to(ISO8601)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeContributionCalendar<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    login: JString<'local>,
    from: JString<'local>,
    to: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let login = jstr(&mut env, &login);
    let from = jstr(&mut env, &from);
    let to = jstr(&mut env, &to);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GraphQLApi::new(client)
            .contribution_calendar(&login, &from, &to)
            .await
    });

    into_jstring(&mut env, result)
}

/// 将 markdown 渲染为 HTML（返回 HTML 字符串）
/// 参数：host, accessToken, text
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeRenderMarkdown<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    text: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let text = jstr(&mut env, &text);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).render_markdown(&text).await
    });

    into_jstring(&mut env, result)
}

// ── Git 工具包（libgit2） ──

/// clone 仓库到本地（返回空串=成功，ERROR:=失败）
/// 参数：url, into, branch(可空), token(可空)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitClone<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    url: JString<'local>,
    into: JString<'local>,
    branch: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let url = jstr(&mut env, &url);
    let into = jstr(&mut env, &into);
    let branch = jstr(&mut env, &branch);
    let token = jstr(&mut env, &token);
    let branch_opt = if branch.is_empty() { None } else { Some(branch.as_str()) };
    let token_opt = if token.is_empty() { None } else { Some(token.as_str()) };

    let result: crate::error::Result<String> =
        crate::git::clone_repo(&url, &into, branch_opt, token_opt).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// pull 仓库（返回空串=成功，ERROR:=失败）
/// 参数：dir, token(可空)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitPull<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let token = jstr(&mut env, &token);
    let token_opt = if token.is_empty() { None } else { Some(token.as_str()) };

    let result: crate::error::Result<String> =
        crate::git::pull_repo(&dir, token_opt).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 更新/新建单文件（`PUT /repos/{o}/{r}/contents/{path}`，返回原始 JSON）
/// 参数：host, token, owner, repo, path, message, content, sha, branch
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativePutContents<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    path: JString<'local>,
    message: JString<'local>,
    content: JString<'local>,
    sha: JString<'local>,
    branch: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let path = jstr(&mut env, &path);
    let message = jstr(&mut env, &message);
    let content = jstr(&mut env, &content);
    let sha = jstr(&mut env, &sha);
    let branch = jstr(&mut env, &branch);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .put_contents(&owner, &repo, &path, &message, &content, &sha, &branch)
            .await
    });

    into_jstring(&mut env, result)
}

/// 批量提交多个文件（Git Data API：blobs → tree → commit → 更新 ref），返回新 commit sha
/// 参数：host, token, owner, repo, branch, message, filesJson（`[{"path":"…","content":"…"}]`）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCommitFiles<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    branch: JString<'local>,
    message: JString<'local>,
    files_json: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let branch = jstr(&mut env, &branch);
    let message = jstr(&mut env, &message);
    let files_json = jstr(&mut env, &files_json);

    let result: crate::error::Result<String> = block_on(async move {
        let parsed: serde_json::Value = serde_json::from_str(&files_json)?;
        let array = parsed
            .as_array()
            .ok_or_else(|| CoreError::Other("filesJson 应为数组".into()))?;
        if array.is_empty() {
            return Err(CoreError::Other("没有要提交的文件".into()));
        }
        let files: Vec<(String, String)> = array
            .iter()
            .map(|f| {
                (
                    f.get("path").and_then(|p| p.as_str()).unwrap_or_default().to_string(),
                    f.get("content").and_then(|c| c.as_str()).unwrap_or_default().to_string(),
                )
            })
            .collect();
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .commit_files(&owner, &repo, &branch, &message, &files)
            .await
    });

    into_jstring(&mut env, result)
}

/// 本地 git commit（暂存 + 提交，返回 commit sha）
/// 参数：dir, message, authorName, authorEmail
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitCommit<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    message: JString<'local>,
    author_name: JString<'local>,
    author_email: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let message = jstr(&mut env, &message);
    let author_name = jstr(&mut env, &author_name);
    let author_email = jstr(&mut env, &author_email);

    let result: crate::error::Result<String> =
        crate::git::commit_repo(&dir, &message, &author_name, &author_email);
    into_jstring(&mut env, result)
}

/// 本地 git push（推送到 origin，返回空串=成功）
/// 参数：dir, token(可空), branch
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitPush<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    token: JString<'local>,
    branch: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let token = jstr(&mut env, &token);
    let branch = jstr(&mut env, &branch);
    let token_opt = if token.is_empty() { None } else { Some(token.as_str()) };

    let result: crate::error::Result<String> =
        crate::git::push_repo(&dir, token_opt, &branch).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 本地分支列表（JSON 数组：name / is_head / upstream / ahead / behind）
/// 参数：dir
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeLocalBranches<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let result: crate::error::Result<String> = crate::git::local_branches(&dir);
    into_jstring(&mut env, result)
}

/// 只刷新远端跟踪引用（fetch，不合并、不动工作区；返回空串=成功）
/// 参数：dir, token(可空), prune(是否顺带清理远端已删除的跟踪引用)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeFetchRemote<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    token: JString<'local>,
    prune: jboolean,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let token = jstr(&mut env, &token);
    let token_opt = if token.is_empty() { None } else { Some(token.as_str()) };
    let prune = prune != 0;

    let result: crate::error::Result<String> =
        crate::git::fetch_remote(&dir, token_opt, prune).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 远端分支清单（JSON 数组：name / local / has_local / ahead / behind）
/// 参数：dir
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeRemoteBranches<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let result: crate::error::Result<String> = crate::git::remote_branches(&dir);
    into_jstring(&mut env, result)
}

/// 切换本地分支（safe checkout，不覆盖未提交改动，返回空串=成功）
/// 参数：dir, name
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCheckoutBranch<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    name: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let name = jstr(&mut env, &name);
    let result: crate::error::Result<String> =
        crate::git::checkout_branch(&dir, &name).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 新建本地分支并切换到它（返回空串=成功）
/// 参数：dir, name, from（空串 = 当前 HEAD）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCreateBranchLocal<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    name: JString<'local>,
    from: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let name = jstr(&mut env, &name);
    let from = jstr(&mut env, &from);
    let result: crate::error::Result<String> =
        crate::git::create_branch_local(&dir, &name, &from).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 删除本地分支（当前分支会被拒绝，返回空串=成功）
/// 参数：dir, name
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeDeleteBranchLocal<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    name: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let name = jstr(&mut env, &name);
    let result: crate::error::Result<String> =
        crate::git::delete_branch_local(&dir, &name).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 撤销工作区所有改动（恢复已跟踪文件 + 删除未跟踪文件，返回空串=成功）
/// 参数：dir
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeDiscardAllChanges<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let result: crate::error::Result<String> =
        crate::git::discard_all_changes(&dir).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 拉取 latest release 的 signature.txt 校验文件内容
/// 参数：host, token, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeLatestReleaseSignature<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .latest_release_signature(&owner, &repo)
            .await
    });

    into_jstring(&mut env, result)
}

/// 拉取仓库 verify/signature.txt 校验文件内容
/// 参数：host, token, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeRepoSignature<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .repo_signature(&owner, &repo)
            .await
    });

    into_jstring(&mut env, result)
}

/// 标记单条通知已读（PATCH /notifications/threads/{id}）
/// 参数：host, token, threadId
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeMarkNotificationRead<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    thread_id: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let thread_id = jstr(&mut env, &thread_id);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .mark_notification_read(&thread_id)
            .await
    });

    into_jstring(&mut env, result)
}

/// 标记全部通知已读（PUT /notifications）
/// 参数：host, token
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeMarkAllNotificationsRead<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .mark_all_notifications_read()
            .await
    });

    into_jstring(&mut env, result)
}
/// 把通知线程标记为「完成」（DELETE /notifications/threads/{id}，返回空串=成功）
/// 参数：host, token, threadId
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeMarkNotificationDone<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    thread_id: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let thread_id = jstr(&mut env, &thread_id);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .mark_notification_done(&thread_id)
            .await
    });

    into_jstring(&mut env, result)
}

/// 静音通知线程（DELETE /notifications/threads/{id}/subscription，返回空串=成功）
/// 参数：host, token, threadId
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeUnsubscribeThread<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    thread_id: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let thread_id = jstr(&mut env, &thread_id);

    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .unsubscribe_thread(&thread_id)
            .await
    });

    into_jstring(&mut env, result)
}

// ── 决策页面支持（对齐 docs/decision-pages-gap.md §6） ──

/// 仓库状态（返回 JSON；ERROR:=失败）
/// 参数：dir
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitStatus<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let result: crate::error::Result<String> = crate::git::repo_status(&dir);
    into_jstring(&mut env, result)
}

/// reset --soft HEAD~1（返回空串=成功）
/// 参数：dir
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitResetSoft<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let result: crate::error::Result<String> =
        crate::git::reset_soft(&dir).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// reset --hard origin/{branch}（返回空串=成功；危险操作，UI 需二次确认）
/// 参数：dir, branch
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitResetHardRemote<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    branch: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let branch = jstr(&mut env, &branch);
    let result: crate::error::Result<String> =
        crate::git::reset_hard_to_remote(&dir, &branch).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 修改最近一次提交信息（amend，返回空串=成功）
/// 参数：dir, message
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitAmend<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    message: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let message = jstr(&mut env, &message);
    let result: crate::error::Result<String> =
        crate::git::amend_message(&dir, &message).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 对已推送提交创建 revert 提交（返回新 sha）
/// 参数：dir, sha, message, authorName, authorEmail
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitRevert<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    sha: JString<'local>,
    message: JString<'local>,
    author_name: JString<'local>,
    author_email: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let sha = jstr(&mut env, &sha);
    let message = jstr(&mut env, &message);
    let author_name = jstr(&mut env, &author_name);
    let author_email = jstr(&mut env, &author_email);
    let result: crate::error::Result<String> =
        crate::git::revert_commit(&dir, &sha, &message, &author_name, &author_email);
    into_jstring(&mut env, result)
}

/// 首次 push：确保 origin + 推送 + 设置上游（返回空串=成功；ERROR:nff:=远端领先被拒）
/// 参数：dir, remoteUrl, branch, token(可空)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitPushSetUpstream<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    remote_url: JString<'local>,
    branch: JString<'local>,
    token: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let remote_url = jstr(&mut env, &remote_url);
    let branch = jstr(&mut env, &branch);
    let token = jstr(&mut env, &token);
    let token_opt = if token.is_empty() { None } else { Some(token.as_str()) };
    let result: crate::error::Result<String> =
        crate::git::push_set_upstream(&dir, &remote_url, &branch, token_opt).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 敏感信息本地扫描（返回 JSON 数组 [{line,kind,mask}]；不上传任何内容）
/// 参数：text
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeScanSensitive<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    text: JString<'local>,
) -> jstring {
    let text = jstr(&mut env, &text);
    let result: crate::error::Result<String> = crate::git::scan_sensitive(&text);
    into_jstring(&mut env, result)
}

/// 初始化 TLS 证书信任（返回空串=成功；ERROR:=失败）
/// 参数：dir（可写目录，如 App cacheDir）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGitInitSsl<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let result: crate::error::Result<String> =
        crate::git::init_ssl_certs(&dir).map(|_| String::new());
    into_jstring(&mut env, result)
}

// ── 协作与仓库管理（PR 一条龙 / 合并 / 仓库设置执行层） ──

/// 读取分支 ref 的 sha
/// 参数：host, token, owner, repo, branch
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGetRefSha<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    branch: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let branch = jstr(&mut env, &branch);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .get_ref_sha(&owner, &repo, &branch)
            .await
    });
    into_jstring(&mut env, result)
}

/// 创建分支
/// 参数：host, token, owner, repo, branch, sha
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCreateBranch<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    branch: JString<'local>,
    sha: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let branch = jstr(&mut env, &branch);
    let sha = jstr(&mut env, &sha);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .create_branch(&owner, &repo, &branch, &sha)
            .await
    });
    into_jstring(&mut env, result)
}

/// 创建 Pull Request
/// 参数：host, token, owner, repo, title, body, head, base, draft("1"/"0")
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCreatePullRequest<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    title: JString<'local>,
    body: JString<'local>,
    head: JString<'local>,
    base: JString<'local>,
    draft: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let title = jstr(&mut env, &title);
    let body = jstr(&mut env, &body);
    let head = jstr(&mut env, &head);
    let base = jstr(&mut env, &base);
    let draft = jstr(&mut env, &draft) == "1";
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .create_pull_request(&owner, &repo, &title, &body, &head, &base, draft)
            .await
    });
    into_jstring(&mut env, result)
}

/// 合并 Pull Request
/// 参数：host, token, owner, repo, number, mergeMethod(merge/squash/rebase)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeMergePullRequest<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    number: JString<'local>,
    merge_method: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let number = jstr(&mut env, &number);
    let merge_method = jstr(&mut env, &merge_method);
    let result: crate::error::Result<String> = block_on(async move {
        let n: u64 = number.parse().unwrap_or(0);
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .merge_pull_request(&owner, &repo, n, &merge_method)
            .await
    });
    into_jstring(&mut env, result)
}

/// 服务端合并分支（A 分支同步到 B 分支；已是最新返回空串）
/// 参数：host, token, owner, repo, base(目标), head(源), message(可空)
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeMergeBranch<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    base: JString<'local>,
    head: JString<'local>,
    message: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let base = jstr(&mut env, &base);
    let head = jstr(&mut env, &head);
    let message = jstr(&mut env, &message);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .merge_branch(&owner, &repo, &base, &head, &message)
            .await
    });
    into_jstring(&mut env, result)
}

/// 比较两个分支（返回 ahead_by/behind_by/status 的 JSON）
/// 参数：host, token, owner, repo, base, head
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCompareBranches<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    base: JString<'local>,
    head: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let base = jstr(&mut env, &base);
    let head = jstr(&mut env, &head);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .compare_branches(&owner, &repo, &base, &head)
            .await
    });
    into_jstring(&mut env, result)
}

/// 更新分支引用（覆盖模式：force=true）
/// 参数：host, token, owner, repo, branch, sha, force
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeUpdateRef<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    branch: JString<'local>,
    sha: JString<'local>,
    force: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let branch = jstr(&mut env, &branch);
    let sha = jstr(&mut env, &sha);
    let force = jstr(&mut env, &force);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .update_ref(&owner, &repo, &branch, &sha, force == "true" || force == "1")
            .await
    });
    into_jstring(&mut env, result)
}

/// 创建 release（草稿/预发布可选，返回原始 JSON）
/// 参数：host, token, owner, repo, tag, name, body, draft, prerelease, targetCommitish, makeLatest
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCreateRelease<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    tag: JString<'local>,
    name: JString<'local>,
    body: JString<'local>,
    draft: JString<'local>,
    prerelease: JString<'local>,
    target_commitish: JString<'local>,
    make_latest: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let tag = jstr(&mut env, &tag);
    let name = jstr(&mut env, &name);
    let body = jstr(&mut env, &body);
    let draft = jstr(&mut env, &draft);
    let prerelease = jstr(&mut env, &prerelease);
    let target_commitish = jstr(&mut env, &target_commitish);
    let make_latest = jstr(&mut env, &make_latest);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .create_release(
                &owner,
                &repo,
                &tag,
                &name,
                &body,
                draft == "true" || draft == "1",
                prerelease == "true" || prerelease == "1",
                &target_commitish,
                &make_latest,
            )
            .await
    });
    into_jstring(&mut env, result)
}

/// 上传 release 资产（返回资产 JSON）
/// 参数：host, token, owner, repo, releaseId, name, filePath, contentType, label
///
/// id 与其它 release 接口一样走字符串（Kotlin 侧是 Long，约定见 nativeUpdateRelease）。
/// label 传空串视为「不带 label」。
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeUploadReleaseAsset<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    release_id: JString<'local>,
    name: JString<'local>,
    file_path: JString<'local>,
    content_type: JString<'local>,
    label: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let release_id = jstr(&mut env, &release_id);
    let name = jstr(&mut env, &name);
    let file_path = jstr(&mut env, &file_path);
    let content_type = jstr(&mut env, &content_type);
    let label = jstr(&mut env, &label);
    let result: crate::error::Result<String> = block_on(async move {
        let id: u64 = release_id.parse().unwrap_or(0);
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .upload_release_asset(
                &owner,
                &repo,
                id,
                &name,
                &file_path,
                &content_type,
                if label.trim().is_empty() { None } else { Some(label.as_str()) },
            )
            .await
    });
    into_jstring(&mut env, result)
}

/// 编辑 release（返回原始 JSON）
/// 参数：host, token, owner, repo, id, tag, name, body, draft, prerelease, makeLatest
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeUpdateRelease<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    id: JString<'local>,
    tag: JString<'local>,
    name: JString<'local>,
    body: JString<'local>,
    draft: JString<'local>,
    prerelease: JString<'local>,
    make_latest: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let id = jstr(&mut env, &id);
    let tag = jstr(&mut env, &tag);
    let name = jstr(&mut env, &name);
    let body = jstr(&mut env, &body);
    let draft = jstr(&mut env, &draft);
    let prerelease = jstr(&mut env, &prerelease);
    let make_latest = jstr(&mut env, &make_latest);
    let result: crate::error::Result<String> = block_on(async move {
        let n: u64 = id.parse().unwrap_or(0);
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .update_release(
                &owner,
                &repo,
                n,
                &tag,
                &name,
                &body,
                draft == "true" || draft == "1",
                prerelease == "true" || prerelease == "1",
                &make_latest,
            )
            .await
    });
    into_jstring(&mut env, result)
}

/// 仓库当前「最新发布」的 id（返回 id 字符串；没有正式发布时返回空串）
/// 参数：host, token, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeLatestReleaseId<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).latest_release_id(&owner, &repo).await
    });
    into_jstring(&mut env, result)
}

/// 生成发布说明（返回原始 JSON：{"name":…,"body":…}）
/// 参数：host, token, owner, repo, tag, targetCommitish
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeGenerateReleaseNotes<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    tag: JString<'local>,
    target_commitish: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let tag = jstr(&mut env, &tag);
    let target_commitish = jstr(&mut env, &target_commitish);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .generate_release_notes(&owner, &repo, &tag, &target_commitish)
            .await
    });
    into_jstring(&mut env, result)
}

/// 删除 release（返回空串=成功）
/// 参数：host, token, owner, repo, id
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeDeleteRelease<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    id: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let id = jstr(&mut env, &id);
    let result: crate::error::Result<String> = block_on(async move {
        let n: u64 = id.parse().unwrap_or(0);
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).delete_release(&owner, &repo, n).await
    });
    into_jstring(&mut env, result)
}

/// 发表 issue 评论（返回原始 JSON）
/// 参数：host, token, owner, repo, number, body
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeCreateIssueComment<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    number: JString<'local>,
    body: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let number = jstr(&mut env, &number);
    let body = jstr(&mut env, &body);
    let result: crate::error::Result<String> = block_on(async move {
        let n: u64 = number.parse().unwrap_or(0);
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .create_issue_comment(&owner, &repo, n, &body)
            .await
    });
    into_jstring(&mut env, result)
}

/// 关闭/重新打开 issue（返回原始 JSON）
/// 参数：host, token, owner, repo, number, state（open / closed）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeUpdateIssue<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    number: JString<'local>,
    state: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let number = jstr(&mut env, &number);
    let state = jstr(&mut env, &state);
    let result: crate::error::Result<String> = block_on(async move {
        let n: u64 = number.parse().unwrap_or(0);
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .update_issue(&owner, &repo, n, &state)
            .await
    });
    into_jstring(&mut env, result)
}

/// 仓库标签列表（返回原始 JSON）
/// 参数：host, token, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeListLabels<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).list_labels(&owner, &repo).await
    });
    into_jstring(&mut env, result)
}

/// 删除远端分支
/// 参数：host, token, owner, repo, branch
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeDeleteBranch<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    branch: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let branch = jstr(&mut env, &branch);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .delete_branch(&owner, &repo, &branch)
            .await
    });
    into_jstring(&mut env, result)
}

/// 修改仓库默认分支
/// 参数：host, token, owner, repo, branch
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeUpdateDefaultBranch<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    branch: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let branch = jstr(&mut env, &branch);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .update_default_branch(&owner, &repo, &branch)
            .await
    });
    into_jstring(&mut env, result)
}

/// 删除仓库
/// 参数：host, token, owner, repo
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeDeleteRepo<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).delete_repo(&owner, &repo).await
    });
    into_jstring(&mut env, result)
}

/// 设置 libgit2 HTTP 代理（返回空串=成功）
/// 参数：dir, proxy（空串=清除）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeSetGitProxy<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    dir: JString<'local>,
    proxy: JString<'local>,
) -> jstring {
    let dir = jstr(&mut env, &dir);
    let proxy = jstr(&mut env, &proxy);
    let result: crate::error::Result<String> =
        crate::git::set_git_proxy(&dir, &proxy).map(|_| String::new());
    into_jstring(&mut env, result)
}

/// 丢弃进程内共享的 HTTP 客户端（含上传专用那一份），让下一次请求重建连接池（返回空串=成功）。
///
/// 网络路径变化后调用（VPN 接入 / 断开、换网）：池里的连接是在切换前的网络上握手完成的，
/// 新路径上复用它们只会一路超时。判定与调用时机在 Kotlin 侧 `NetworkWatch`。
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeResetHttpClient<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    crate::api::client::reset_http_client();
    let result: crate::error::Result<String> = Ok(String::new());
    into_jstring(&mut env, result)
}

/// 更新当前用户资料（PATCH /user，返回空串=成功）
/// 参数：host, token, body（JSON 字符串）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeUpdateProfile<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    body: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let body = jstr(&mut env, &body);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).update_profile(&body).await
    });
    into_jstring(&mut env, result)
}

/// 解析工作流 YAML 的 `on.workflow_dispatch`（返回 JSON：enabled + inputs[]）
/// 参数：yaml（工作流文件全文）
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeParseWorkflowInputs<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    yaml: JString<'local>,
) -> jstring {
    let yaml = jstr(&mut env, &yaml);
    let result: crate::error::Result<String> =
        Ok(crate::workflow::parse_dispatch_spec_json(&yaml));
    into_jstring(&mut env, result)
}

/// 手动触发工作流（POST /repos/{o}/{r}/actions/workflows/{id}/dispatches，返回空串=成功）
/// 参数：host, token, owner, repo, workflowId, gitRef, inputsJson
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeDispatchWorkflow<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
    workflow_id: JString<'local>,
    git_ref: JString<'local>,
    inputs_json: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let workflow_id = jstr(&mut env, &workflow_id);
    let git_ref = jstr(&mut env, &git_ref);
    let inputs_json = jstr(&mut env, &inputs_json);
    let result: crate::error::Result<String> = block_on(async move {
        let id: u64 = workflow_id.parse().unwrap_or(0);
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client)
            .dispatch_workflow(&owner, &repo, id, &git_ref, &inputs_json)
            .await
    });
    into_jstring(&mut env, result)
}

// ── 仓库关系（星标 / 关注 / 复刻）的写入与网页通道 ──

/// 通用 PUT（JSON body；空串 = 发空体）
/// 参数：host, token, path, body
///
/// 星标是 `PUT /user/starred/{o}/{r}`（空体，官方要求 `Content-Length: 0`），
/// 关注是 `PUT /repos/{o}/{r}/subscription`（JSON）。两者共用这一个入口。
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativePutJson<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    token: JString<'local>,
    path: JString<'local>,
    body: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let token = jstr(&mut env, &token);
    let path = jstr(&mut env, &path);
    let body = jstr(&mut env, &body);
    let result: crate::error::Result<String> = block_on(async move {
        let client = crate::api::ApiClient::new(&host, &token);
        crate::api::GitHubApi::new(client).put_json_or_empty(&path, &body).await
    });
    into_jstring(&mut env, result)
}

/// 取仓库页的判定数据（`react-app.embeddedData`，网页版的唯一真源）
/// 参数：host, cookie, owner, repo
///
/// 返回的是**已剥离出来的小 JSON**（几 KB），不是 230KB 的整页 HTML ——
/// 调用方要解析 `payload.sidebarAbout` 里的 star / fork / watch。
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeWebRepoEmbedded<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    cookie: JString<'local>,
    owner: JString<'local>,
    repo: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let cookie = jstr(&mut env, &cookie);
    let owner = jstr(&mut env, &owner);
    let repo = jstr(&mut env, &repo);
    let result: crate::error::Result<String> = block_on(async move {
        crate::api::WebSession::new(host, cookie).repo_embedded(&owner, &repo).await
    });
    into_jstring(&mut env, result)
}

/// 调网页内部端点（POST 表单）
/// 参数：host, cookie, pagePath, postPath, formJson
///
/// `formJson` 是 `[[key, value], …]` —— 用数组而不是对象，是因为
/// `thread_types[]` 需要**同名多值**，JSON 对象表达不了。
#[no_mangle]
pub extern "system" fn Java_com_branchbase_core_RustBridge_nativeWebPostForm<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    host: JString<'local>,
    cookie: JString<'local>,
    page_path: JString<'local>,
    post_path: JString<'local>,
    form_json: JString<'local>,
) -> jstring {
    let host = jstr(&mut env, &host);
    let cookie = jstr(&mut env, &cookie);
    let page_path = jstr(&mut env, &page_path);
    let post_path = jstr(&mut env, &post_path);
    let form_json = jstr(&mut env, &form_json);
    let result: crate::error::Result<String> = block_on(async move {
        let pairs: Vec<(String, String)> = serde_json::from_str(&form_json)
            .map_err(|e| crate::error::CoreError::InvalidArgument(format!("表单字段不是 [[k,v],…]：{e}")))?;
        crate::api::WebSession::new(host, cookie)
            .post_form(&page_path, &post_path, &pairs)
            .await
    });
    into_jstring(&mut env, result)
}
