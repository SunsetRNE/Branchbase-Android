package com.branchbase.ui.home

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import com.branchbase.core.AccountStore
import com.branchbase.core.RustBridge
import com.branchbase.ui.theme.iconTap
import com.branchbase.ui.theme.Avatar
import com.branchbase.cache.PageCache
import com.branchbase.cache.SearchCacheDatabase
import com.branchbase.cache.SearchCacheManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.branchbase.ui.theme.Primer
import com.branchbase.cache.RepoPrefetcher
import com.branchbase.ui.notification.NotificationPrefetcher
import org.json.JSONObject

/**
 * 首页 Dashboard。
 *
 * 结构：搜索栏+头像 / 待处理 / 进行中 / 常用仓库 / 最近活动。
 */
@Composable
fun HomeScreen(
    sessionJson: String,
    onProfileClick: () -> Unit,
    onSearchClick: () -> Unit,
    onRepoClick: (String) -> Unit = {},
    onOpenNotifications: () -> Unit = {},
) {
    val context = LocalContext.current
    val user = runCatching { JSONObject(sessionJson).getJSONObject("user") }.getOrNull()
    // login 兜底：session.user → 当前账号（多账号表）→ 占位
    val login = user?.optString("login")?.takeIf { it.isNotBlank() && it != "null" }
        ?: AccountStore.currentLogin(context).takeIf { it.isNotBlank() }
        ?: "用户"
    val avatarUrl = user?.optString("avatar_url")?.takeIf { it.isNotBlank() }

    // 解析 token 与 host，用于拉取数据
    val token = runCatching { JSONObject(sessionJson).getJSONObject("token").optString("access_token") }.getOrNull() ?: ""
    val host = runCatching { JSONObject(sessionJson).optString("host", "github.com") }.getOrDefault("github.com")
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("branchbase", Context.MODE_PRIVATE) }

    var repos by remember { mutableStateOf<List<StarredRepo>>(emptyList()) }
    var events by remember { mutableStateOf<List<Activity>>(emptyList()) }

    // 加载星标（先读缓存，再网络刷新）
    suspend fun loadStarred(refresh: Boolean) {
        if (!refresh) {
            prefs.getString("starred_repos", null)?.let { repos = parseStarredRepos(it) }
        }
        RustBridge.getStarredRepos(host, token)?.let { json ->
            if (!json.startsWith("ERROR:")) {
                repos = parseStarredRepos(json)
                prefs.edit().putString("starred_repos", json).apply()
            }
        }
    }

    // 加载最近活动（先读缓存，再网络刷新）
    suspend fun loadEvents(refresh: Boolean) {
        if (!refresh) {
            prefs.getString("recent_events", null)?.let { events = parseActivities(it) }
        }
        // 首页展示「我自己的活动」→ /user/events（含私有仓库）。
        // 不要用 received_events：那是「我关注的人的活动」feed，通常为空。
        RustBridge.getJson(host, token, "/user/events?per_page=50")?.let { json ->
            if (!json.startsWith("ERROR:")) {
                events = parseActivities(json)
                prefs.edit().putString("recent_events", json).apply()
            }
        }
    }

    // 首页仪表盘数据（对齐 design/home-redesign-prototype.html）
    var unreadNotifs by remember { mutableStateOf(0) }
    var reviewRequests by remember { mutableStateOf(0) }
    var assignedIssues by remember { mutableStateOf(0) }
    var runningTasks by remember { mutableStateOf<List<com.branchbase.ui.task.TaskRecord>>(emptyList()) }

    // 仪表盘计数缓存（TTL 5 分钟）。星标/活动仍走各自的 prefs 缓存，不受影响。
    val cacheManager = remember(context) {
        SearchCacheManager(SearchCacheDatabase.getInstance(context).searchCacheDao())
    }

    /**
     * 计数类请求的「缓存直出 + 回源写回」。
     *
     * 语义与改动前一致：失败静默为 0、不打扰首页；区别只在**回源前先读缓存**，
     * 未过期（5 分钟）时 [PageCache.refresh] 直接返回缓存、不再发请求。
     * 每次回到前台仍会走一遍这里（本函数无 force 入口），命中未过期缓存即免流量。
     *
     * 解析与改动前逐一对应：
     * - 通知计数 = `/notifications` 返回数组的长度；
     * - 评审/指派计数 = 搜索接口返回对象的 `total_count`。
     */
    suspend fun loadCachedCount(name: String, fetch: suspend () -> String?): Int {
        val json = PageCache.refresh(cacheManager, PageCache.homeKey(name), PageCache.TYPE_HOME) {
            withContext(Dispatchers.IO) { fetch() }
        } ?: return 0
        return runCatching {
            if (json.trimStart().startsWith("[")) {
                org.json.JSONArray(json).length()
            } else {
                JSONObject(json).optInt("total_count", 0)
            }
        }.getOrDefault(0)
    }

    LaunchedEffect(Unit) {
        // 5 个互不依赖的请求并行（原来是串行：星标 → 活动 → 通知 → 评审 → 指派）
        coroutineScope {
            launch { loadStarred(false) }
            launch { loadEvents(false) }
            // 待处理三件套（都是轻量请求，失败静默为 0，不打扰首页）
            // 每个计数各自 key（home:unread / home:review / home:assigned），类型 TYPE_HOME（TTL 5 分钟）
            // 消息首屏预取（需求 ③）：原来这里请求 `/notifications?per_page=100` **只为了数长度**，
            // 而消息页进去还要再请求一次首屏 —— 同一份数据两条腿各拉一遍。
            // 现在这一步把首屏做完整：写 PageCache（落盘）+ 填 NotifSnapshot（已解析），
            // 未读数也从同一份数据算出，于是「进消息页」= 0 次网络 + 0 帧骨架。
            // 被策略跳过（计费网络 / 关闭了预加载开关）时返回 null，回退到原来的计数路径。
            launch {
                unreadNotifs = NotificationPrefetcher.warmUp(context, host, token)
                    ?: loadCachedCount("unread") {
                        RustBridge.getJson(host, token, "/notifications?per_page=100")
                    }
            }
            launch {
                reviewRequests = loadCachedCount("review") {
                    RustBridge.searchIssues(host, token, "review-requested:@me state:open type:pr")
                }
            }
            launch {
                assignedIssues = loadCachedCount("assigned") {
                    RustBridge.searchIssues(host, token, "assignee:@me state:open")
                }
            }
        }
        // 进行中任务：本地 Room，零网络请求
        runningTasks = com.branchbase.ui.task.TaskStore.list(context)
            .filter { it.status == com.branchbase.ui.task.TaskStatus.RUNNING }
        // 预加载：星标首屏几个仓库的详情，点进去直接命中缓存（计费网络下自动跳过）
        RepoPrefetcher.warmList(
            context = context,
            host = host,
            token = token,
            entries = repos.map {
                it.fullName.substringBefore('/') to it.fullName.substringAfter('/', "")
            },
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Primer.BackgroundPrimary),
    ) {
        // 顶部：搜索栏 + 头像
        SearchBarRow(login = login, avatarUrl = avatarUrl, onProfileClick = onProfileClick, onSearchClick = onSearchClick)

        // 内容：仪表盘式分区（待处理 → 进行中 → 常用 → 浏览）
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item { GreetingRow(login) }

            // ① 待处理：需要你动手的
            item { SectionHeader("待处理", Icons.Filled.Notifications) }
            item {
                TodoCard(
                    unread = unreadNotifs,
                    reviews = reviewRequests,
                    assigned = assignedIssues,
                    onOpenNotifications = onOpenNotifications,
                    onOpenSearch = onSearchClick,
                )
            }

            // ② 进行中：本地任务（零网络）
            if (runningTasks.isNotEmpty()) {
                item { SectionHeader("进行中", Icons.Filled.Timeline) }
                item { RunningTasksCard(runningTasks) }
            }

            // ③ 常用仓库（星标，最多 5 个）
            item {
                SectionHeader("常用仓库", Icons.Filled.Star) {
                    scope.launch { loadStarred(true) }
                }
            }
            if (repos.isEmpty()) {
                item { EmptyState("暂无星标仓库") }
            } else {
                items(repos.take(5)) { repo -> RepoCard(repo, onClick = { onRepoClick(repo.fullName) }) }
            }

            // ④ 最近活动（只留 3 条，完整列表在个人主页的动态页）
            item {
                SectionHeader("最近活动", Icons.Filled.History) {
                    scope.launch { loadEvents(true) }
                }
            }
            if (events.isEmpty()) {
                item { EmptyState("暂无最近活动") }
            } else {
                items(events.take(3)) { act -> ActivityItem(act) }
            }
        }
    }
}

/** 解析 /user/starred 返回的 JSON 数组 */
private fun parseStarredRepos(json: String): List<StarredRepo> {
    return runCatching {
        val arr = org.json.JSONArray(json)
        (0 until arr.length()).map { i ->
            val obj = arr.getJSONObject(i)
            StarredRepo(
                fullName = obj.optString("full_name"),
                desc = obj.optString("description").orEmpty(),
                language = obj.optString("language").takeIf { it.isNotBlank() },
                stars = obj.optLong("stargazers_count").let { formatCount(it) },
                forks = obj.optLong("forks_count").let { formatCount(it) },
            )
        }
    }.getOrDefault(emptyList())
}

private fun formatCount(n: Long): String = when {
    n >= 1000 -> "%.1fk".format(n / 1000.0)
    else -> n.toString()
}

/** 解析 received_events 返回的 JSON 数组 */
private fun parseActivities(json: String): List<Activity> {
    return runCatching {
        val arr = org.json.JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val obj = arr.getJSONObject(i)
            val type = obj.optString("type")
            val actor = obj.optJSONObject("actor")?.optString("login") ?: return@mapNotNull null
            val repoName = obj.optJSONObject("repo")?.optString("name") ?: ""
            val createdAt = obj.optString("created_at")
            val (icon, verb) = when (type) {
                "WatchEvent" -> Icons.Filled.Star to "star 了"
                "ForkEvent" -> Icons.Filled.CallSplit to "fork 了"
                "IssuesEvent" -> Icons.Filled.ErrorOutline to "在 issue 上操作"
                "PullRequestEvent" -> Icons.Filled.CallSplit to "提交了 PR 到"
                "PushEvent" -> Icons.Filled.Code to "推送代码到"
                "CreateEvent" -> Icons.Filled.Add to "创建了"
                else -> return@mapNotNull null
            }
            Activity(
                icon = icon,
                text = "$actor $verb $repoName",
                time = relativeTime(createdAt),
            )
        }
    }.getOrDefault(emptyList())
}

/** ISO 时间转相对时间 */
private fun relativeTime(iso: String): String {
    return runCatching {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val epoch = fmt.parse(iso)?.time ?: return@runCatching iso
        val minutes = (System.currentTimeMillis() - epoch) / 60000
        when {
            minutes < 1 -> "刚刚"
            minutes < 60 -> "$minutes 分钟前"
            minutes < 1440 -> "${minutes / 60} 小时前"
            else -> "${minutes / 1440} 天前"
        }
    }.getOrDefault(iso)
}

/** 搜索栏 + 头像（头像点击进个人页） */
@Composable
private fun SearchBarRow(login: String, avatarUrl: String?, onProfileClick: () -> Unit, onSearchClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // 搜索框（点击进搜索页）
        Row(
            modifier = Modifier
                .weight(1f)
                .height(40.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Primer.BackgroundSecondary)
                .clickable { onSearchClick() }
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Search, contentDescription = "搜索", tint = Primer.IconSecondary, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("搜索 GitHub", fontSize = 14.sp, color = Primer.TextTertiary)
        }
        Spacer(Modifier.width(10.dp))
        // 头像（40dp 圆）—— 统一组件：本地缓存优先 + 按尺寸取图 + 首字母占位
        Avatar(
            url = avatarUrl,
            login = login,
            size = 40.dp,
            // 反馈必须是圆形：Avatar 内部的 clip 在调用方 modifier **之后**，
            // 直接传 clickable 会让水波纹溢成正方形（iconTap 把 clip 提到点击之前）
            modifier = Modifier.iconTap { onProfileClick() },
        )
    }
}

/** 问候语（首页顶部）。 */
@Composable
private fun GreetingRow(login: String) {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val greet = when {
        hour < 6 -> "夜深了"
        hour < 12 -> "早上好"
        hour < 18 -> "下午好"
        else -> "晚上好"
    }
    Text(
        "$greet，$login",
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        color = Primer.TextPrimary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
    )
}

/**
 * 待处理卡片：未读通知 / 待我审查 / 分配给我。
 *
 * 三行都是「需要你动手的」，全为 0 时显示空态而不是隐藏整块 —— 保持首屏结构稳定。
 */
@Composable
private fun TodoCard(
    unread: Int,
    reviews: Int,
    assigned: Int,
    onOpenNotifications: () -> Unit,
    onOpenSearch: () -> Unit,
) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, Primer.Border, RoundedCornerShape(10.dp)),
    ) {
        if (unread + reviews + assigned == 0) {
            Box(Modifier.fillMaxWidth().padding(vertical = 22.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("没有待办", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text("需要你处理的 PR / issue / 通知会出现在这里", fontSize = 11.5.sp, color = Primer.TextTertiary)
                }
            }
            return@Column
        }
        TodoRow("未读通知", "$unread 条", Primer.InfoSurfaceSoft, Primer.Blue500, unread > 0, onOpenNotifications)
        TodoRow("待我审查", "$reviews 个 PR", Primer.SuccessSurface, Primer.Green500, reviews > 0, onOpenSearch)
        TodoRow(
            "分配给我", "$assigned 个 issue", Primer.WarningSurface, Primer.WarningTextStrong,
            assigned > 0, onOpenSearch, last = true,
        )
    }
}

@Composable
private fun TodoRow(
    title: String,
    value: String,
    iconBg: Color,
    iconFg: Color,
    enabled: Boolean,
    onClick: () -> Unit,
    last: Boolean = false,
) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(26.dp).clip(RoundedCornerShape(8.dp)).background(iconBg),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(iconFg))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (enabled) Primer.TextPrimary else Primer.TextTertiary,
            )
            Text(value, fontSize = 11.sp, color = Primer.TextTertiary, modifier = Modifier.padding(top = 1.dp))
        }
        Text("›", fontSize = 15.sp, color = Primer.TextTertiary)
    }
    if (!last) Box(Modifier.fillMaxWidth().height(1.dp).background(Primer.Border.copy(alpha = 0.4f)))
}

/** 进行中任务卡片（数据来自本地 TaskStore，零网络）。 */
@Composable
private fun RunningTasksCard(tasks: List<com.branchbase.ui.task.TaskRecord>) {
    val shown = tasks.take(3)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, Primer.Border, RoundedCornerShape(10.dp)),
    ) {
        shown.forEachIndexed { index, t ->
            Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        t.title,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Primer.TextPrimary,
                        maxLines = 1,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        if (t.progress in 0..100) "${t.progress}%" else "运行中",
                        fontSize = 11.sp,
                        color = Primer.Blue500,
                    )
                }
                if (t.progress in 0..100) {
                    Spacer(Modifier.height(7.dp))
                    Box(
                        Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Primer.Gray150),
                    ) {
                        Box(
                            Modifier.fillMaxWidth(t.progress / 100f).height(5.dp)
                                .clip(RoundedCornerShape(3.dp)).background(Primer.Blue500),
                        )
                    }
                }
                if (t.detail.isNotBlank()) {
                    Text(
                        t.detail,
                        fontSize = 11.sp,
                        color = Primer.TextTertiary,
                        maxLines = 1,
                        modifier = Modifier.padding(top = 5.dp),
                    )
                }
            }
            if (index < shown.lastIndex) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(Primer.Border.copy(alpha = 0.4f)))
            }
        }
    }
}

/** 区块标题（图标 + 文字 + 可选刷新按钮） */
@Composable
private fun SectionHeader(title: String, icon: ImageVector, onRefresh: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = Primer.IconPrimary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Primer.TextPrimary)
        Spacer(Modifier.weight(1f))
        if (onRefresh != null) {
            Icon(
                Icons.Filled.Refresh,
                contentDescription = "刷新",
                tint = Primer.IconSecondary,
                modifier = Modifier.size(18.dp).iconTap { onRefresh() },
            )
        }
    }
}

/** 仓库卡片 */
@Composable
private fun RepoCard(repo: StarredRepo, onClick: () -> Unit = {}) {
    Column(
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Primer.BackgroundSecondary)
            .clickable { onClick() }
            .padding(14.dp),
    ) {
        Text(repo.fullName, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Primer.Blue500)
        if (repo.desc.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(repo.desc, fontSize = 13.sp, color = Primer.TextSecondary)
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            if (repo.language != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(langColor(repo.language)))
                    Spacer(Modifier.width(4.dp))
                    Text(repo.language, fontSize = 12.sp, color = Primer.TextSecondary)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Star, contentDescription = "星标", tint = Primer.IconSecondary, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(2.dp))
                Text(repo.stars, fontSize = 12.sp, color = Primer.TextSecondary)
            }
            if (repo.forks != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CallSplit, contentDescription = "复刻", tint = Primer.IconSecondary, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(2.dp))
                    Text(repo.forks, fontSize = 12.sp, color = Primer.TextSecondary)
                }
            }
        }
    }
}

/** 活动项 */
@Composable
private fun ActivityItem(act: Activity) {
    Row(
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Primer.BackgroundSecondary)
            .padding(12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Primer.BackgroundPrimary),
            contentAlignment = Alignment.Center,
        ) {
            Icon(act.icon, contentDescription = null, tint = Primer.IconPrimary, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(act.text, fontSize = 13.sp, color = Primer.TextSecondary)
            Spacer(Modifier.height(3.dp))
            Text(act.time, fontSize = 11.sp, color = Primer.TextTertiary)
        }
    }
}

/** 空态 */
@Composable
private fun EmptyState(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Primer.TextTertiary, fontSize = 13.sp)
    }
}

/** 星标仓库（来自 /user/starred） */
private data class StarredRepo(
    val fullName: String,
    val desc: String,
    val language: String?,
    val stars: String,
    val forks: String? = null,
)

/** 活动（来自 received_events） */
private data class Activity(
    val icon: ImageVector,
    val text: String,
    val time: String,
)

/** GitHub 语言色映射 */
private fun langColor(lang: String?): Color = when (lang) {
    "Kotlin" -> Color(0xFFA97BFF)
    "Rust" -> Color(0xFFDEA584)
    "Java" -> Color(0xFFB07219)
    "Python" -> Color(0xFF3572A5)
    "JavaScript" -> Color(0xFFF1E05A)
    "TypeScript" -> Color(0xFF3178C6)
    "Go" -> Color(0xFF00ADD8)
    "Swift" -> Color(0xFFF05138)
    "C++" -> Color(0xFFF34B7D)
    "C" -> Color(0xFF555555)
    "Dart" -> Color(0xFF00B4AB)
    else -> Color(0xFF8B949E)
}