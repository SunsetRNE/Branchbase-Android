package com.branchbase.ui.profile

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import java.io.File
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.branchbase.ui.navigation.PageBackHandler
import com.branchbase.ui.repository.RepoRelation
import com.branchbase.ui.theme.selectionColor
import com.branchbase.BuildConfig
import com.branchbase.core.AccountStatus
import com.branchbase.ui.settings.frameWatchEnabled
import com.branchbase.ui.settings.gitProxy
import com.branchbase.ui.settings.setFrameWatchEnabled
import com.branchbase.translate.TranslateSettings
import com.branchbase.core.AccountStore
import com.branchbase.ui.log.FrameWatch
import com.branchbase.ui.log.LogLevel
import com.branchbase.ui.log.LogManager
import com.branchbase.ui.settings.AccountRow
import com.branchbase.ui.settings.ChoiceRow
import com.branchbase.ui.settings.DangerRow
import com.branchbase.ui.settings.DisabledNavRow
import com.branchbase.ui.settings.NavRow
import com.branchbase.ui.settings.SettingsProse
import com.branchbase.ui.settings.SettingsSection
import com.branchbase.ui.settings.StatusTone
import com.branchbase.ui.settings.SwitchRow
import com.branchbase.ui.settings.displayGitProxy
import com.branchbase.ui.theme.ThemeMode
import com.branchbase.ui.theme.ThemeRuntime
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.Commit
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tune
import com.branchbase.core.LocalRepos
import com.branchbase.core.RustBridge
import com.branchbase.ui.log.Logger
import com.branchbase.ui.notification.NotifLayout
import com.branchbase.ui.notification.readNotifLayout
import com.branchbase.ui.notification.rememberSystemNotificationState
import com.branchbase.ui.notification.writeNotifLayout
import com.branchbase.ui.theme.iconTap
import com.branchbase.ui.theme.LanguageColors
import com.branchbase.ui.theme.AppIcon
import com.branchbase.ui.theme.Primer
import com.branchbase.ui.task.TaskKind
import com.branchbase.ui.task.TaskStore
import com.branchbase.ui.decision.AuthorIdentityScreen
import com.branchbase.ui.decision.DeleteRepoWarningScreen
import com.branchbase.ui.decision.ForkDecisionScreen
import com.branchbase.ui.decision.GitifyRollbackScreen
import com.branchbase.ui.decision.StageCommitScreen
import com.branchbase.ui.decision.StageFile
import com.branchbase.ui.decision.UpstreamSetupScreen
import com.branchbase.ui.decision.UndoCommitScreen
import com.branchbase.ui.decision.parseGitStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * More 菜单子页面（星标 / 软件包 / 项目 / 设置）。
 *
 * 由气泡弹窗选项直接跳转进入，不留存导航栏层级；返回回到「个人主页」。
 * 三个数据页（星标/软件包/项目）统一接入「缓存 + 快速预加载渲染 + 数据过期 + 强制刷新」机制，
 * 避免重复请求服务器导致限流/拉黑。
 */
enum class SubPage(val label: String) {
    Stars("星标"),
    Projects("项目"),
    EditProfile("编辑资料"),
    Settings("设置"),
    LocalRepo("本地仓库"),
    About("关于"),
    Log("日志"),
    NotificationSettings("通知设置"),
    Translate("沉浸式翻译"),
    Tasks("任务"),
    Accounts("账号"),
    CommitMode("提交模式"),
    GitProxy("Git 代理"),
}

// ───────────────────────── 缓存机制（内存缓存 + TTL 过期） ─────────────────────────

/** 内存级数据缓存：key -> (原始 JSON, 写入时间戳) */
internal object ProfileCache {
    private class Entry(val data: String, val time: Long)
    private val map = mutableMapOf<String, Entry>()

    /** 命中未过期的缓存返回原始 JSON，否则返回 null */
    fun get(key: String, ttlMs: Long): String? {
        val e = map[key] ?: return null
        if (System.currentTimeMillis() - e.time > ttlMs) {
            map.remove(key)
            return null
        }
        return e.data
    }

    fun put(key: String, data: String) {
        map[key] = Entry(data, System.currentTimeMillis())
    }
}

/** 各数据类型过期时长（毫秒），避免频繁请求 */
internal object ProfileTtl {
    const val STARS = 15L * 60 * 1000      // 15 分钟
    const val PACKAGES = 15L * 60 * 1000   // 15 分钟
    const val PROJECTS = 15L * 60 * 1000   // 15 分钟
}

// ───────────────────────── 数据模型 & 解析 ─────────────────────────

internal data class PackageItem(
    val name: String,
    val packageType: String,
    val visibility: String? = null,
    val versionCount: Long = 0,
)

internal data class ProjectItem(
    val name: String,
    val description: String? = null,
)

internal fun parsePackages(json: String): List<PackageItem> {
    return runCatching {
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val it = arr.getJSONObject(i)
            PackageItem(
                name = it.optString("name"),
                packageType = it.optString("package_type"),
                visibility = it.optString("visibility").takeIf { v -> v.isNotBlank() && v != "null" },
                versionCount = it.optLong("version_count"),
            )
        }
    }.getOrDefault(emptyList())
}

internal fun parseProjects(json: String): List<ProjectItem> {
    return runCatching {
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val it = arr.getJSONObject(i)
            ProjectItem(
                name = it.optString("name"),
                description = it.optString("body").takeIf { d -> d.isNotBlank() && d != "null" },
            )
        }
    }.getOrDefault(emptyList())
}

// ───────────────────────── 公共组件 ─────────────────────────

/** 子页面顶部返回导航（返回箭头 + 标题 + 可选右侧操作） */
@Composable
internal fun SubPageHeader(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回", tint = Primer.IconPrimary, modifier = Modifier.size(24.dp).iconTap { onBack() })
        Spacer(Modifier.width(8.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

/** 强制刷新按钮（Material Refresh 图标，无 emoji） */
@Composable
private fun RefreshButton(onRefresh: () -> Unit) {
    Icon(
        Icons.Filled.Refresh,
        contentDescription = "刷新",
        tint = Primer.Blue500,
        modifier = Modifier.size(20.dp).iconTap { onRefresh() },
    )
}

// ───────────────────────── 星标页 ─────────────────────────

@Composable
fun StarsScreen(sessionJson: String, onBack: () -> Unit, onOpenRepo: (String) -> Unit) {
    LaunchedEffect(Unit) { Logger.ui("进入星标页", "Compose") }
    val context = LocalContext.current
    val token = runCatching { JSONObject(sessionJson).getJSONObject("token").optString("access_token") }.getOrNull() ?: ""
    val host = runCatching { JSONObject(sessionJson).optString("host", "github.com") }.getOrDefault("github.com")
    // 关系判定要当前账号：星标里既有自己的仓库也有别人的，用于区分「我的 / 协作 / 他人」
    val me = remember(sessionJson, context) {
        runCatching { JSONObject(sessionJson).getJSONObject("user").optString("login") }
            .getOrNull()?.takeIf { it.isNotBlank() && it != "null" }
            ?: com.branchbase.core.AccountStore.currentLogin(context)
    }
    var repos by remember { mutableStateOf<List<RepoItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshKey) {
        val cacheKey = "stars"
        // 快速预加载渲染：首次进入先读缓存
        if (refreshKey == 0) {
            val cached = ProfileCache.get(cacheKey, ProfileTtl.STARS)
            if (cached != null) {
                repos = parseRepos(cached, me = me)
                loading = false
                return@LaunchedEffect
            }
        }
        loading = true
        val json = withContext(Dispatchers.IO) { RustBridge.getStarredRepos(host, token) }
        Logger.net("GET /user/starred → ${if (json != null && !json.startsWith("ERROR:")) "200" else "失败"}", "GitHubAPI")
        if (json != null && !json.startsWith("ERROR:")) {
            repos = parseRepos(json, me = me)
            ProfileCache.put(cacheKey, json)
        } else {
            repos = emptyList()
        }
        loading = false
        // 预加载首屏几个仓库的详情（点进去直接命中缓存；计费网络自动跳过）
        com.branchbase.cache.RepoPrefetcher.warmList(
            context = context,
            host = host,
            token = token,
            entries = repos.map {
                it.fullName.substringBefore('/') to it.fullName.substringAfter('/', "")
            },
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Primer.BackgroundPrimary).statusBarsPadding().navigationBarsPadding(),
    ) {
        SubPageHeader("星标", onBack) {
            Text("${repos.size}", fontSize = 13.sp, color = Primer.TextTertiary)
            Spacer(Modifier.width(12.dp))
            RefreshButton { refreshKey++ }
        }
        // 原先这里是一个不可点的「搜索星标」占位框，已随占位清理移除；
        // 需要搜索时走首页的搜索入口（全局搜索页支持按仓库/代码等类型检索）。
        if (loading) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("加载中", color = Primer.TextTertiary) }
        } else if (repos.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("暂无星标", fontSize = 13.sp, color = Primer.TextTertiary) }
        } else {
            LazyColumn {
                items(repos) { repo -> StarredRepoCard(repo, onClick = { onOpenRepo(repo.fullName) }) }
            }
        }
    }
}

@Composable
private fun StarredRepoCard(repo: RepoItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.size(32.dp).clip(CircleShape).background(Primer.Blue500), contentAlignment = Alignment.Center) {
            Text(repo.name.take(1).uppercase(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(repo.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Primer.Blue500)
            if (repo.description != null) {
                Spacer(Modifier.height(2.dp))
                Text(repo.description, fontSize = 12.5.sp, color = Primer.TextSecondary, lineHeight = 18.sp)
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (repo.language != null) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(LanguageColors.of(repo.language)))
                    Spacer(Modifier.width(4.dp))
                    Text(repo.language, fontSize = 12.sp, color = Primer.TextTertiary)
                    Spacer(Modifier.width(8.dp))
                }
                Icon(Icons.Filled.Star, contentDescription = null, tint = Primer.TextTertiary, modifier = Modifier.size(12.dp))
                Spacer(Modifier.width(2.dp))
                Text("${repo.stars}", fontSize = 12.sp, color = Primer.TextTertiary)
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.clip(RoundedCornerShape(6.dp)).background(Primer.WarningSurface).border(1.dp, Primer.Border, RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("已星标", fontSize = 12.sp, color = Primer.WarningTextStrong)
        }
    }
}

// ───────────────────────── 项目页 ─────────────────────────

@Composable
fun ProjectsScreen(sessionJson: String, onBack: () -> Unit) {
    LaunchedEffect(Unit) { Logger.ui("进入项目页", "Compose") }
    val token = runCatching { JSONObject(sessionJson).getJSONObject("token").optString("access_token") }.getOrNull() ?: ""
    val host = runCatching { JSONObject(sessionJson).optString("host", "github.com") }.getOrDefault("github.com")
    var projects by remember { mutableStateOf<List<ProjectItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(refreshKey) {
        val cacheKey = "projects"
        if (refreshKey == 0) {
            val cached = ProfileCache.get(cacheKey, ProfileTtl.PROJECTS)
            if (cached != null) {
                projects = parseProjects(cached)
                loading = false
                return@LaunchedEffect
            }
        }
        loading = true
        val json = withContext(Dispatchers.IO) { RustBridge.getMyProjects(host, token) }
        Logger.net("GET /user/projects → ${if (json != null && !json.startsWith("ERROR:")) "200" else "失败"}", "GitHubAPI")
        if (json != null && !json.startsWith("ERROR:")) {
            projects = parseProjects(json)
            ProfileCache.put(cacheKey, json)
        } else {
            projects = emptyList()
        }
        loading = false
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Primer.BackgroundPrimary).statusBarsPadding().navigationBarsPadding(),
    ) {
        SubPageHeader("项目", onBack) {
            RefreshButton { refreshKey++ }
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.clip(RoundedCornerShape(6.dp)).background(Primer.Green500).padding(horizontal = 12.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(2.dp))
                    Text("新建", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
                }
            }
        }
        if (loading) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("加载中", color = Primer.TextTertiary) }
        } else if (projects.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("暂无项目", fontSize = 13.sp, color = Primer.TextTertiary) }
        } else {
            LazyColumn {
                items(projects) { project -> ProjectCard(project) }
            }
        }
    }
}

@Composable
private fun ProjectCard(project: ProjectItem) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Text(project.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
        if (project.description != null) {
            Spacer(Modifier.height(2.dp))
            Text(project.description, fontSize = 12.5.sp, color = Primer.TextSecondary, lineHeight = 18.sp)
        }
    }
}

// ───────────────────────── 设置页 ─────────────────────────

/**
 * 提交模式（三选项，对齐 commit-mode-decision-tree.md）。
 *
 * ## 为什么 `label` 必须短、长描述单独放 [title]
 *
 * 原来只有 `label` 一个字段，于是「本地仓库」模式把整句描述
 * （`文件拉取到本地仓库，由本地 git 管理提交推送`）当成了状态文案：设置页那一行、
 * 决策页副标题、编辑器底栏都直接用它 —— 这些位置是**单行状态位**，
 * 长文案挤掉同排的内容（设置页把「提交模式」这个名字压到换行、被 48dp 行高裁掉）。
 *
 * 现在按用途拆开：
 * - [label]：短名，用于**状态位**（设置项右侧值 / 当前模式 / 编辑页底栏 / 日志 / toast）；
 * - [title]：完整说明，只用于**整行卡片**（提交模式页、首次引导页、提交时选择弹窗）；
 * - [desc]：一句话补充，与 [title] 搭配在卡片里显示。
 */
internal enum class CommitMode(
    val label: String,
    val title: String,
    val desc: String,
) {
    SINGLE_FILE("单个文件", "单个文件更改，单个提交", "官方客户端行为 · 编辑即提交"),
    MULTI_FILE("多文件合并", "多个文件更改，合并一次提交", "网页端行为 · 暂存区统一提交"),
    LOCAL_REPO("本地仓库（Git）", "文件拉取到本地仓库，由本地 git 管理提交推送", "Git 命令行习惯"),
}

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenLocalRepo: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenLog: () -> Unit,
    onOpenNotificationSettings: () -> Unit,
    onOpenTranslate: () -> Unit,
    onOpenAccounts: () -> Unit,
    onOpenCommitMode: () -> Unit,
    onOpenGitProxy: () -> Unit,
    onLogout: () -> Unit,
) {
    LaunchedEffect(Unit) { Logger.ui("进入设置页", "Compose") }
    val context = LocalContext.current

    // 提交模式决定「本地仓库」那一行是导航行还是禁用态（规范 §6.3）
    val mode = commitMode(context)
    val themeMode by ThemeRuntime.mode.collectAsState()
    val notificationPermission = rememberSystemNotificationState()
    val account = remember { AccountStore.current(context) }

    var translateEnabled by remember { mutableStateOf(TranslateSettings.read(context).enabled) }
    var confirmLogout by remember { mutableStateOf(false) }
    // 慢帧日志开关：只在这里读一次盘（默认值来自编译通道），之后由用户点击驱动
    var frameWatch by remember { mutableStateOf(frameWatchEnabled(context)) }

    // 错误数只取一次快照：设置页不做高频重组，没必要给「日志」行挂订阅
    val logErrors = remember { LogManager.all().count { it.level == LogLevel.ERROR } }

    LazyColumn(
        // 惰性化：设置页有 8 组卡片、二十多行，`Column + verticalScroll` 会在**首帧**
        // 把整棵树组合出来（真机实测「进入设置页」首帧 43~89ms，其中重组≈绘制）；
        // 换成 LazyColumn 后首帧只组合可见的那几组，剩下的滚到才建。
        modifier = Modifier.fillMaxSize().background(Primer.BackgroundPrimary).statusBarsPadding().navigationBarsPadding(),
    ) {

        item {
            SubPageHeader("设置", onBack)
        }

        item {
            Spacer(Modifier.height(6.dp))
        }

        // ── ① 账户：身份是第一信息（规范 §3.2） ──
        item {
            SettingsSection("账户") {
                AccountRow(
                    login = account?.login,
                    host = account?.host,
                    // 账户卡的头像必须传下去：Avatar 内部按「本地缓存 → avatar_url → 首字母」
                    // 依次回落并做圆形裁切；漏传这一项，圈选处就只剩写死的首字母。
                    // 用 avatarUrl（快照缺失时回落会话 user.avatar_url）而不是裸 avatar。
                    avatar = account?.avatarUrl,
                    statusLabel = account?.status?.label,
                    statusTone = account?.status?.let { accountStatusTone(it) } ?: StatusTone.MUTE,
                    onClick = onOpenAccounts,
                )
            }
        }

        // ── ② 外观：三档分段控件，取代「点一下循环」（规范 §5.2） ──
        item {
            SettingsSection("外观") {
                ChoiceRow(
                    icon = Icons.Filled.Palette,
                    name = "主题",
                    sub = "选「跟随系统」时，App 会随系统的浅色 / 深色自动切换。",
                    options = ThemeMode.entries.map { it to it.label },
                    selected = themeMode,
                    onSelect = { ThemeRuntime.set(context, it) },
                    divider = false,
                )
            }
        }

        // ── ③ 通知 ──
        item {
            SettingsSection("通知") {
                // 这一行**不是**开关：系统通知权限不是 App 的布尔值，App 只能申请或跳系统设置。
                // 用导航行 + 状态胶囊，才不会让「开了但系统没授权」变成一个骗人的开关（规范 §4.3）。
                NavRow(
                    icon = Icons.Filled.Notifications,
                    name = "通知",
                    sub = notificationPermission.hint,
                    value = notificationPermission.label,
                    onClick = onOpenNotificationSettings,
                    divider = false,
                )
            }
        }

        // ── ④ 翻译 ──
        item {
            SettingsSection("翻译") {
                SwitchRow(
                    icon = Icons.Filled.Translate,
                    name = "自动翻译正文",
                    sub = if (translateEnabled) {
                        "进入自述文件等正文页会自动翻译，页面上出现可移动悬浮球。"
                    } else {
                        "关闭后不进正文页翻译，页面上的悬浮球也会收起。"
                    },
                    checked = translateEnabled,
                    onCheckedChange = {
                        translateEnabled = it
                        TranslateSettings.setEnabled(context, it)
                    },
                    divider = false,
                )
                NavRow(
                    icon = Icons.Filled.Tune,
                    name = "沉浸式翻译",
                    onClick = onOpenTranslate,
                )
            }
        }

        // ── ⑤ 代码与提交 ──
        item {
            SettingsSection("代码与提交") {
                NavRow(
                    icon = Icons.Filled.Commit,
                    name = "提交模式",
                    value = mode?.label ?: "未设置",
                    onClick = onOpenCommitMode,
                    divider = false,
                )
                if (mode == CommitMode.LOCAL_REPO) {
                    NavRow(
                        icon = Icons.Filled.Folder,
                        name = "本地仓库",
                        onClick = onOpenLocalRepo,
                    )
                } else {
                    // 禁用态**不能只调 alpha**：说明原因 + 给出去开启的路（规范 §6.3）
                    DisabledNavRow(
                        icon = Icons.Filled.Folder,
                        name = "本地仓库",
                        reason = "开启需先将「提交模式」设为「本地仓库（Git）」。",
                        onFix = onOpenCommitMode,
                    )
                }
            }
        }

        // ── ⑥ 网络 ──
        item {
            SettingsSection("网络") {
                NavRow(
                    icon = Icons.Filled.Language,
                    name = "Git 代理",
                    // 值列只显示 host:port，凭据不进列表（规范 §6.5）
                    value = displayGitProxy(gitProxy(context)).ifEmpty { "未设置" },
                    sub = "仅作用于本地仓库的 clone / pull / push。",
                    onClick = onOpenGitProxy,
                    divider = false,
                )
            }
        }

        // ── ⑦ 关于与诊断：兜底组，位置固定（规范 §3.3） ──
        item {
            SettingsSection("关于与诊断") {
                // 慢帧日志：诊断仪表。默认值随编译通道（Beta 开 / 正式版关，见 build.gradle.kts 的
                // FRAME_WATCH_DEFAULT），这里可以随时覆盖 —— 正式版用户要抓一次卡顿就靠它。
                SwitchRow(
                    icon = Icons.Filled.Speed,
                    name = "慢帧日志",
                    sub = if (frameWatch) {
                        "记录每次卡顿的耗时与分段（等待 / 动画 / 绘制 …）并带上页面名；日志每天 0 点换目录、旧的丢弃。"
                    } else {
                        "关闭后不再记录慢帧；已经写进日志的内容不受影响。"
                    },
                    checked = frameWatch,
                    onCheckedChange = {
                        frameWatch = it
                        setFrameWatchEnabled(context, it)
                        FrameWatch.setEnabled(it)
                    },
                    divider = false,
                )
                NavRow(
                    icon = Icons.AutoMirrored.Filled.Article,
                    name = "日志",
                    value = if (logErrors > 0) "$logErrors 条错误" else null,
                    onClick = onOpenLog,
                )
                NavRow(
                    icon = Icons.Filled.Info,
                    name = "关于",
                    value = BuildConfig.STANDARD_VERSION,
                    onClick = onOpenAbout,
                )
            }
        }

        // ── 危险动作：单独一组、放最末（规范 §7.2） ──
        item {
            SettingsSection {
                DangerRow(
                    icon = Icons.AutoMirrored.Filled.Logout,
                    name = if (account != null) "退出登录 ${account.login}" else "退出登录",
                    hint = "不可撤销",
                    onClick = { confirmLogout = true },
                    divider = false,
                )
            }
        }

        item {
            Spacer(Modifier.height(12.dp))
        }
    }

    // 二次确认：标题 = 动词 + 对象名；正文三条（会发生什么 / 影响范围 / 能否撤销）；
    // 确认按钮写**动词**，不写「确定」（规范 §7.2 / §7.3）
    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            title = {
                Text(
                    if (account != null) "退出登录 ${account.login}" else "退出登录",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Primer.TextPrimary,
                )
            },
            text = {
                Text(
                    "将清除本机保存的凭据，并切回未登录状态。\n" +
                        "本地仓库目录、已下载内容与站内通知不受影响。\n" +
                        "此操作不可撤销 —— 需要重新走一次授权才能恢复。",
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    color = Primer.TextSecondary,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmLogout = false
                    onLogout()
                }) { Text("退出登录", color = Primer.DangerText) }
            },
            dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text("取消") } },
        )
    }
}



/** 账号状态 → 胶囊语气（规范 §4.3：状态要能一眼分辨「好 / 警告 / 坏」）。 */
private fun accountStatusTone(status: AccountStatus): StatusTone = when (status) {
    AccountStatus.OK -> StatusTone.OK
    AccountStatus.UNKNOWN -> StatusTone.MUTE
    AccountStatus.LIMITED, AccountStatus.UNREACHABLE -> StatusTone.WARN
    AccountStatus.INVALID, AccountStatus.SUSPENDED -> StatusTone.BAD
}

/** 通知设置子页面：系统通知权限入口 + 通知列表显示模式。 */
@Composable
fun NotificationSettingsScreen(onBack: () -> Unit) {
    LaunchedEffect(Unit) { Logger.ui("进入通知设置页", "Compose") }
    val context = LocalContext.current
    var layout by remember { mutableStateOf(readNotifLayout(context)) }
    // 系统通知（权限 + 总开关）：与下载通知、通知页横幅读同一份状态
    val permission = rememberSystemNotificationState()

    Column(
        modifier = Modifier.fillMaxSize().background(Primer.BackgroundPrimary).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        SubPageHeader("通知", onBack)
        Spacer(Modifier.height(6.dp))

        SettingsSection("系统通知") {
            // 已开启 → 进系统设置（可关掉 / 改渠道）；未开启 → 能弹授权框就弹，否则去设置页
            NavRow(
                icon = Icons.Filled.Notifications,
                name = "允许发送通知",
                sub = permission.hint,
                value = permission.label,
                onClick = { if (permission.granted) permission.openSettings() else permission.request() },
                divider = false,
            )
        }

        SettingsSection("通知显示模式") {
            NotifLayout.entries.forEachIndexed { i, l ->
                ModeOptionRow(
                    label = l.label,
                    desc = l.desc,
                    selected = layout == l,
                    divider = i != 0,
                ) {
                    layout = l
                    writeNotifLayout(context, l)
                }
            }
        }

        SettingsSection("说明") {
            SettingsProse(
                "「允许发送通知」只控制系统通知栏的提醒（下载进度 / 下载完成）：关掉它，站内通知列表与未读徽标照常工作。\n" +
                    "通知列表的展示方式：「平铺」为默认：每条通知独立成卡；分组/合并/两级模式可将相关通知折叠，减少列表长度。",
                divider = false,
            )
        }

        Spacer(Modifier.height(12.dp))
    }
}


/**
 * 二级页的单选行：18dp 圆点 + 名称 + 说明（规范 §5.4：「4–7 档枚举走 L2 单选列表」）。
 *
 * 每行**必须**有说明 —— 单选列表的选择质量完全取决于说明文案。
 *
 * 两处配色是**按对比度审计定的**，不是随手挑的：
 * - 未选中描边走 [Primer.BorderControl]（可交互控件边界，WCAG 1.4.11 要 ≥3:1）；
 *   `Primer.Border` 是装饰性描边，只有 1.80:1。
 * - 选中圆点走 [Primer.SuccessTextStrong]，不用 `Primer.Green500`：
 *   后者压在 `SuccessSurface` 上只有 2.79:1，而圆点是**唯一**表达「选了哪个」的图形。
 */
@Composable
internal fun ModeOptionRow(
    label: String,
    desc: String,
    selected: Boolean,
    divider: Boolean = false,
    onClick: () -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        if (divider) Box(Modifier.fillMaxWidth().height(1.dp).background(Primer.Gray200))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(selectionColor(selected, on = Primer.SuccessSurface))
                .clickable { onClick() }
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            // 单选圆点：外圈与填充一起渐变（设置页里每个开关都会走这条路径）
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .border(
                        2.dp,
                        selectionColor(selected, on = Primer.SuccessTextStrong, off = Primer.BorderControl),
                        CircleShape,
                    )
                    .background(selectionColor(selected, on = Primer.SuccessTextStrong)),
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(desc, fontSize = 12.sp, color = Primer.TextTertiary)
            }
        }
    }
}


// ───────────────────────── 本地仓库列表页 ─────────────────────────

/** 本地仓库页内页面状态机（列表 / 各决策页）。 */
private sealed interface LocalPage {
    data object List : LocalPage
    data class Fork(val name: String) : LocalPage
    data class Undo(val name: String) : LocalPage
    data class Upstream(val name: String) : LocalPage
    data class Rollback(val name: String) : LocalPage
    data class DeleteWarn(val name: String, val unpushed: kotlin.collections.List<com.branchbase.ui.decision.UnpushedCommit>) : LocalPage
    data class Stage(val name: String) : LocalPage
    data class Identity(val name: String, val message: String) : LocalPage
    /** 本地分支管理（列表 / 切换 / 新建 / 删除） */
    data class Branches(val name: String) : LocalPage
    /** 本地 ↔ 远端分支同步（fetch + 按分支推送/拉取/建跟踪） */
    data class Sync(val name: String) : LocalPage
}

/**
 * 本地仓库列表页。每个仓库独立 Git（更新/删除），「＋拉取仓库」列出我的仓库并浅 clone。
 * clone 通过 `RustBridge.gitClone`（libgit2）。
 * 决策收口：pull/push 分叉 → Fork 页；删除升级警告；提交/撤销/上游/回退入口。
 */
@Composable
fun LocalRepoScreen(sessionJson: String, onBack: () -> Unit) {
    LaunchedEffect(Unit) { Logger.ui("进入本地仓库页", "Compose") }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val accountLogin = remember { AccountStore.currentLogin(context) }
    val repoRoot = remember(accountLogin) { LocalRepos.rootFor(context, accountLogin) }
    var repos by remember { mutableStateOf(listLocalRepos(repoRoot)) }
    val host = remember(sessionJson) { runCatching { JSONObject(sessionJson).optString("host", "github.com") }.getOrDefault("github.com") }
    val token = remember(sessionJson) {
        runCatching { JSONObject(sessionJson).optJSONObject("token")?.optString("access_token").orEmpty() }.getOrDefault("")
    }
    val login = remember(sessionJson) {
        runCatching { JSONObject(sessionJson).optJSONObject("user")?.optString("login").orEmpty() }.getOrDefault("")
    }

    var myRepos by remember { mutableStateOf<List<RepoItem>>(emptyList()) }
    var showPicker by remember { mutableStateOf(false) }
    var loadingRepos by remember { mutableStateOf(false) }
    var cloning by remember { mutableStateOf(false) }
    var feedback by remember { mutableStateOf<String?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }

    // 决策页状态机
    var page by remember { mutableStateOf<LocalPage>(LocalPage.List) }

    // 返回键先消费「本页自己的决策页」：这一页内部有十来个子页（分叉 / 撤销 / 上游 / 回退 /
    // 删除警告 / 暂存提交 / 身份 / 分支 / 同步），它们的左上角返回都是「回本地仓库列表」，
    // 系统返回键必须走同一个目标。否则按返回会直接跳出整个「本地仓库」页，
    // 用户精心进入的决策页连同已填内容一起消失（与外层 ProfileScreen 的返回键相比，
    // 这里后注册、优先级更高，所以能抢到）。
    PageBackHandler(page != LocalPage.List) { page = LocalPage.List }

    // 提示统一走 Snackbar：浮在内容之上，不占用列表布局、不挤动页面
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedback) {
        val msg = feedback ?: return@LaunchedEffect
        feedback = null
        snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
    }

    fun authorName() = context.getSharedPreferences("branchbase", Context.MODE_PRIVATE)
        .getString("commit.author.name", "") ?: "Branchbase"

    fun authorEmail() = context.getSharedPreferences("branchbase", Context.MODE_PRIVATE)
        .getString("commit.author.email", "") ?: "branchbase@users.noreply.github.com"

    fun dirOf(name: String) = File(repoRoot, name).absolutePath

    // 各仓库当前分支（用于行内显示；随仓库列表变化刷新）
    var branchMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    LaunchedEffect(repos) {
        val m = mutableMapOf<String, String>()
        repos.forEach { r ->
            val st = withContext(Dispatchers.IO) {
                RustBridge.gitStatus(dirOf(r))?.let { parseGitStatus(it) }
            }
            st?.branch?.takeIf { it.isNotBlank() }?.let { m[r] = it }
        }
        branchMap = m
    }
    fun branchOf(name: String) = branchMap[name] ?: "—"

    /** pull 三态：成功 / 分叉（→ Fork 决策页）/ 失败。 */
    fun doPull(name: String) {
        scope.launch {
            feedback = null
            val taskId = TaskStore.start(context, TaskKind.PULL, "更新仓库 $name")
            val pullResult = withContext(Dispatchers.IO) { RustBridge.gitPullDetailed(dirOf(name), token) }
            // 错误同时落日志：UI 的 feedback 一闪而过无法回看，日志才能事后定位
            Logger.net("git pull ($name) → ${pullResult ?: "成功"}", "LocalGit")
            when (pullResult) {
                null -> { TaskStore.success(context, taskId, "已更新"); feedback = "已更新 $name" }
                "nff" -> { TaskStore.fail(context, taskId, "本地与远端分叉（需决策）"); page = LocalPage.Fork(name) }
                else -> { TaskStore.fail(context, taskId, pullResult); feedback = "更新失败：$pullResult" }
            }
        }
    }

    /** push 三态：无 upstream 先引导设置（P2-2），被拒 → Fork 决策页。 */
    fun doPush(name: String) {
        scope.launch {
            feedback = null
            val st = withContext(Dispatchers.IO) { RustBridge.gitStatus(dirOf(name))?.let { parseGitStatus(it) } }
            if (st == null) { feedback = "无法读取仓库状态（引擎不可用）"; return@launch }
            if (!st.hasUpstream) { page = LocalPage.Upstream(name); return@launch }
            val taskId = TaskStore.start(context, TaskKind.PUSH, "推送仓库 $name")
            val pushResult = withContext(Dispatchers.IO) { RustBridge.gitPushDetailed(dirOf(name), token, st.branch) }
            Logger.net("git push ${st.branch} ($name) → ${pushResult ?: "成功"}", "LocalGit")
            when (pushResult) {
                null -> { TaskStore.success(context, taskId, "已推送 ${st.branch}"); feedback = "已推送 $name" }
                "nff" -> { TaskStore.fail(context, taskId, "推送被拒（远端领先）"); page = LocalPage.Fork(name) }
                else -> { TaskStore.fail(context, taskId, pushResult); feedback = "推送失败：$pushResult" }
            }
        }
    }

    /** 删除请求：ahead>0 时升级为独立确认页（P1-3），否则普通确认框。 */
    fun doDeleteRequest(name: String) {
        scope.launch {
            val st = withContext(Dispatchers.IO) { RustBridge.gitStatus(dirOf(name))?.let { parseGitStatus(it) } }
            if (st != null && st.ahead > 0) {
                page = LocalPage.DeleteWarn(name, st.unpushed)
            } else {
                deleteTarget = name
            }
        }
    }

    /** 本地提交入口：工作区有改动才进暂存页（P0-2）。 */
    fun doStageCommit(name: String) {
        scope.launch {
            val st = withContext(Dispatchers.IO) { RustBridge.gitStatus(dirOf(name))?.let { parseGitStatus(it) } }
            if (st == null || st.dirty.isEmpty()) { feedback = "工作区没有改动可提交"; return@launch }
            page = LocalPage.Stage(name)
        }
    }

    /** 执行本地 git commit（identity 已就绪）。 */
    fun doGitCommit(repoName: String, message: String) {
        scope.launch {
            val taskId = TaskStore.start(context, TaskKind.COMMIT, "本地提交 $repoName")
            val sha = withContext(Dispatchers.IO) {
                RustBridge.gitCommit(dirOf(repoName), message, authorName(), authorEmail())
            }
            Logger.net("git commit ($repoName) → ${sha?.take(7) ?: "失败"}", "LocalGit")
            if (sha != null) TaskStore.success(context, taskId, "已提交 $sha")
            else TaskStore.fail(context, taskId, "提交失败（引擎不可用）")
            feedback = if (sha != null) "已提交（本地 git）" else "提交失败（引擎不可用）"
            page = LocalPage.List
        }
    }

    /** 提交前身份检查（P0-3：首次无签名时先配置）。 */
    fun commitOrIdentity(name: String, message: String) {
        val prefs = context.getSharedPreferences("branchbase", Context.MODE_PRIVATE)
        if (prefs.getString("commit.author.name", null) == null || prefs.getString("commit.author.email", null) == null) {
            page = LocalPage.Identity(name, message)
        } else {
            doGitCommit(name, message)
        }
    }

    // ── 决策页分发 ──
    when (val p = page) {
        is LocalPage.Fork -> {
            ForkDecisionScreen(
                repoName = p.name,
                repoDir = dirOf(p.name),
                token = token,
                onBack = { page = LocalPage.List },
                onResolved = { msg -> feedback = msg; page = LocalPage.List },
            )
            return
        }
        is LocalPage.Undo -> {
            UndoCommitScreen(
                repoName = p.name,
                repoDir = dirOf(p.name),
                onBack = { page = LocalPage.List },
                onResolved = { msg -> feedback = msg; page = LocalPage.List },
            )
            return
        }
        is LocalPage.Upstream -> {
            UpstreamSetupScreen(
                repoName = p.name,
                repoDir = dirOf(p.name),
                token = token,
                onBack = { page = LocalPage.List },
                onResolved = { msg, fork ->
                    if (fork) page = LocalPage.Fork(p.name)
                    else { feedback = msg; page = LocalPage.List }
                },
            )
            return
        }
        is LocalPage.Rollback -> {
            GitifyRollbackScreen(
                repoName = p.name,
                repoDir = dirOf(p.name),
                onBack = { page = LocalPage.List },
                onDeletedRepo = {
                    scope.launch {
                        val st = withContext(Dispatchers.IO) { RustBridge.gitStatus(dirOf(p.name))?.let { parseGitStatus(it) } }
                        page = LocalPage.DeleteWarn(p.name, st?.unpushed ?: emptyList())
                    }
                },
                onResolved = { msg -> feedback = msg; page = LocalPage.List },
            )
            return
        }
        is LocalPage.DeleteWarn -> {
            DeleteRepoWarningScreen(
                repoName = p.name,
                unpushed = p.unpushed,
                onBack = { page = LocalPage.List },
                onPushFirst = {
                    // 先推送再删：直接走 push（无 upstream 引导设置；被拒转分叉）
                    page = LocalPage.List
                    doPush(p.name)
                },
                onDelete = {
                    scope.launch {
                        File(repoRoot, p.name).deleteRecursively()
                        repos = listLocalRepos(repoRoot)
                        feedback = "已删除 ${p.name}"
                        page = LocalPage.List
                    }
                },
            )
            return
        }
        is LocalPage.Stage -> {
            var dirtyFiles by remember(p.name) { mutableStateOf<List<StageFile>>(emptyList()) }
            LaunchedEffect(p.name) {
                val st = withContext(Dispatchers.IO) { RustBridge.gitStatus(dirOf(p.name))?.let { parseGitStatus(it) } }
                dirtyFiles = st?.dirty?.map { StageFile(it.path, it.status, checked = true) } ?: emptyList()
            }
            StageCommitScreen(
                repoName = p.name,
                files = dirtyFiles,
                mode = CommitMode.LOCAL_REPO,
                onBack = { page = LocalPage.List },
                onPickMode = { /* 已由弹窗固化 */ },
                onCommit = { message, _ -> commitOrIdentity(p.name, message) },
            )
            return
        }
        is LocalPage.Identity -> {
            AuthorIdentityScreen(
                suggestedName = login.ifBlank { "Branchbase" },
                suggestedEmail = "${login.ifBlank { "branchbase" }}@users.noreply.github.com",
                onBack = { page = LocalPage.List },
                onConfirm = { name, email, save ->
                    if (save) {
                        context.getSharedPreferences("branchbase", Context.MODE_PRIVATE)
                            .edit().putString("commit.author.name", name).putString("commit.author.email", email).apply()
                    }
                    doGitCommit(p.name, p.message)
                },
            )
            return
        }
        is LocalPage.Branches -> {
            var branchList by remember(p.name) { mutableStateOf<List<LocalBranch>>(emptyList()) }
            var branchDirty by remember(p.name) { mutableIntStateOf(0) }
            var branchBusy by remember(p.name) { mutableStateOf(false) }
            var branchError by remember(p.name) { mutableStateOf<String?>(null) }
            var reloadKey by remember(p.name) { mutableIntStateOf(0) }

            LaunchedEffect(p.name, reloadKey) {
                branchList = withContext(Dispatchers.IO) { parseLocalBranches(RustBridge.localBranches(dirOf(p.name))) }
                branchDirty = withContext(Dispatchers.IO) {
                    RustBridge.gitStatus(dirOf(p.name))?.let { parseGitStatus(it) }?.dirty?.size ?: 0
                }
            }

            BranchesScreen(
                repoName = p.name,
                branches = branchList,
                dirtyCount = branchDirty,
                busy = branchBusy,
                error = branchError,
                onBack = { page = LocalPage.List },
                onRefresh = { reloadKey++ },
                onCheckout = { target ->
                    scope.launch {
                        branchBusy = true
                        branchError = null
                        // 脏工作区：用户已在对话框确认「撤销并切换」
                        if (branchDirty > 0) {
                            val discardErr = withContext(Dispatchers.IO) { RustBridge.discardAllChanges(dirOf(p.name)) }
                            if (discardErr != null) {
                                branchError = discardErr
                                branchBusy = false
                                return@launch
                            }
                        }
                        val err = withContext(Dispatchers.IO) { RustBridge.checkoutBranch(dirOf(p.name), target) }
                        Logger.net("git checkout $target (${p.name}) → ${err ?: "成功"}", "LocalGit")
                        branchBusy = false
                        if (err == null) {
                            feedback = "已切换到 $target"
                            page = LocalPage.List
                        } else {
                            branchError = err
                        }
                    }
                },
                onDelete = { target ->
                    scope.launch {
                        branchBusy = true
                        branchError = null
                        val err = withContext(Dispatchers.IO) { RustBridge.deleteBranchLocal(dirOf(p.name), target) }
                        Logger.net("git branch -d $target (${p.name}) → ${err ?: "成功"}", "LocalGit")
                        branchBusy = false
                        if (err == null) {
                            feedback = "已删除分支 $target"
                            reloadKey++
                        } else {
                            branchError = err
                        }
                    }
                },
                onCreate = { newBranch ->
                    scope.launch {
                        branchBusy = true
                        branchError = null
                        val err = withContext(Dispatchers.IO) {
                            RustBridge.createBranchLocal(dirOf(p.name), newBranch, "")
                        }
                        Logger.net("git switch -c $newBranch (${p.name}) → ${err ?: "成功"}", "LocalGit")
                        branchBusy = false
                        if (err == null) {
                            feedback = "已创建并切换到 $newBranch"
                            page = LocalPage.List
                        } else {
                            branchError = err
                        }
                    }
                },
            )
            return
        }
        is LocalPage.Sync -> {
            com.branchbase.ui.repository.LocalBranchSyncScreen(
                dir = dirOf(p.name),
                repoName = p.name,
                token = token,
                onBack = { page = LocalPage.List },
                onChanged = { repos = listLocalRepos(repoRoot) },
            )
            return
        }
        is LocalPage.List -> Unit
    }

    // 拉取我的仓库
    fun loadMyRepos() {
        if (loadingRepos) return
        loadingRepos = true
        scope.launch {
            val json = withContext(Dispatchers.IO) { RustBridge.getMyRepos(host, token) }
            myRepos = json?.takeIf { !it.startsWith("ERROR:") }?.let { parseRepos(it, me = accountLogin) } ?: emptyList()
            loadingRepos = false
        }
    }

    // clone 一个仓库
    fun doClone(fullName: String, name: String) {
        showPicker = false
        // repos 根目录必须存在（libgit2 clone 不会自动创建父目录）
        if (!repoRoot.exists() && !repoRoot.mkdirs()) {
            feedback = "无法创建本地仓库目录"
            return
        }
        val target = File(repoRoot, name)
        if (target.exists()) {
            feedback = "「$name」已存在"
            return
        }
        scope.launch {
            cloning = true
            feedback = null
            val taskId = TaskStore.start(context, TaskKind.CLONE, "拉取仓库 $fullName")
            val error = RustBridge.gitCloneDetailed("https://github.com/$fullName", target.absolutePath, "", token)
            if (error == null) TaskStore.success(context, taskId, "已拉取到 ${target.name}")
            else TaskStore.fail(context, taskId, error)
            Logger.remote(if (error == null) "git clone $fullName 完成" else "git clone $fullName 失败：$error", "libgit2")
            cloning = false
            feedback = if (error == null) "已拉取 $name" else "拉取失败：$error"
            repos = listLocalRepos(repoRoot)
        }
    }

    // Box 包裹：Snackbar 浮在内容之上，不占用列表布局、不会挤动页面
    Box(Modifier.fillMaxSize()) {
    Column(
        modifier = Modifier.fillMaxSize().background(Primer.BackgroundPrimary).statusBarsPadding().navigationBarsPadding(),
    ) {
        SubPageHeader("本地仓库", onBack) {
            Text("${repos.size} 个", fontSize = 12.sp, color = Primer.TextTertiary)
        }

        // ＋拉取仓库
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Primer.Green500)
                .clickable { showPicker = true; if (myRepos.isEmpty()) loadMyRepos() }
                .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("拉取仓库", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
            }
        }

        if (cloning) {
            Text("正在克隆…", fontSize = 12.sp, color = Primer.TextTertiary, modifier = Modifier.padding(horizontal = 16.dp))
        }

        if (repos.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Folder, null, tint = Primer.IconSecondary, modifier = Modifier.size(40.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("暂无本地仓库", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
                    Spacer(Modifier.height(4.dp))
                    Text("点击「拉取仓库」将仓库克隆到本地", fontSize = 12.sp, color = Primer.TextTertiary)
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(repos) { name ->
                    LocalRepoRow(
                        name = name,
                        branch = branchOf(name),
                        onBranches = { page = LocalPage.Branches(name) },
                        onSync = { page = LocalPage.Sync(name) },
                        onPull = { doPull(name) },
                        onPush = { doPush(name) },
                        onCommit = { doStageCommit(name) },
                        onUndo = { page = LocalPage.Undo(name) },
                        onUpstream = { page = LocalPage.Upstream(name) },
                        onRollback = { page = LocalPage.Rollback(name) },
                        onDelete = { doDeleteRequest(name) },
                    )
                }
            }
        }
    }

    // 仓库选择对话框
    if (showPicker) {
        Dialog(onDismissRequest = { showPicker = false }) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Primer.BackgroundPrimary, RoundedCornerShape(12.dp))
                    .padding(16.dp),
            ) {
                Text("选择要拉取的仓库", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Primer.TextPrimary)
                Spacer(Modifier.height(10.dp))
                if (loadingRepos) {
                    Text("加载中…", fontSize = 13.sp, color = Primer.TextTertiary)
                } else if (myRepos.isEmpty()) {
                    Text("暂无仓库", fontSize = 13.sp, color = Primer.TextTertiary)
                } else {
                    LazyColumn(Modifier.heightIn(max = 400.dp)) {
                        items(myRepos) { repo ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable { doClone(repo.fullName, repo.name) }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(repo.fullName, fontSize = 14.sp, color = Primer.TextPrimary, modifier = Modifier.weight(1f))
                                // 我的 / 协作 / 他人：`/user/repos` 默认就包含协作与组织仓库，
                                // 不标出来用户会以为列表里全是自己的
                                RepoRelationBadge(repo.relation)
                            }
                        }
                    }
                }
            }
        }
    }
        SnackbarHost(
            snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
        )
    }

    // 删除确认
    deleteTarget?.let { name ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("删除本地仓库") },
            text = { Text("确定删除「$name」吗？仅删除本地副本，不影响远端仓库。") },
            confirmButton = {
                TextButton(onClick = {
                    deleteTarget = null
                    scope.launch {
                        File(repoRoot, name).deleteRecursively()
                        repos = listLocalRepos(repoRoot)
                    }
                }) { Text("删除", color = Primer.Red500) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("取消") } },
        )
    }
}

private fun listLocalRepos(root: File): List<String> =
    root.listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList()

@Composable
private fun LocalRepoRow(
    name: String,
    branch: String,
    onBranches: () -> Unit,
    onSync: () -> Unit,
    onPull: () -> Unit,
    onPush: () -> Unit,
    onCommit: () -> Unit,
    onUndo: () -> Unit,
    onUpstream: () -> Unit,
    onRollback: () -> Unit,
    onDelete: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Primer.Border, RoundedCornerShape(8.dp))
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Primer.Blue500)
            Spacer(Modifier.weight(1f))
            // 当前分支胶囊 → 分支管理页
            Row(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Primer.Gray150)
                    .clickable { onBranches() }
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("⑂ ${branch.ifBlank { "—" }}", fontSize = 11.sp, color = Primer.TextSecondary)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("更新", fontSize = 12.sp, color = Primer.Blue500, modifier = Modifier.clickable { onPull() })
            Text("推送", fontSize = 12.sp, color = Primer.Blue500, modifier = Modifier.clickable { onPush() })
            Text("分支同步", fontSize = 12.sp, color = Primer.Blue500, modifier = Modifier.clickable { onSync() })
            Text("提交", fontSize = 12.sp, color = Primer.Green500, modifier = Modifier.clickable { onCommit() })
            Text("撤销", fontSize = 12.sp, color = Primer.TextSecondary, modifier = Modifier.clickable { onUndo() })
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("上游", fontSize = 12.sp, color = Primer.TextSecondary, modifier = Modifier.clickable { onUpstream() })
            Text("回退 Git 化", fontSize = 12.sp, color = Primer.TextSecondary, modifier = Modifier.clickable { onRollback() })
            Text("删除", fontSize = 12.sp, color = Primer.Red500, modifier = Modifier.clickable { onDelete() })
        }
    }
}

// ───────────────────────── 本地分支管理 ─────────────────────────

/** 本地分支（nativeLocalBranches 的 JSON 解析结果）。 */
internal data class LocalBranch(
    val name: String,
    val isHead: Boolean,
    val upstream: String,
    val ahead: Int,
    val behind: Int,
)

private fun parseLocalBranches(json: String?): List<LocalBranch> {
    if (json.isNullOrBlank()) return emptyList()
    return runCatching {
        val arr = org.json.JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            LocalBranch(
                name = o.optString("name"),
                isHead = o.optBoolean("is_head", false),
                upstream = o.optString("upstream"),
                ahead = o.optInt("ahead", 0),
                behind = o.optInt("behind", 0),
            )
        }
    }.getOrDefault(emptyList())
}

/** main / master 视为受保护分支：删除入口置灰不可点。 */
private fun isProtectedBranch(name: String) = name == "main" || name == "master"

/**
 * 本地分支管理页。
 *
 * 交互约定（对齐本轮确定的规则）：
 * - 脏工作区切换：先弹确认，确认后**撤销所有改动再切换**（不做隐式 stash）
 * - 删除：当前分支不显示删除入口；main/master 置灰
 * - 新建：基于当前分支，创建后自动切换
 */
@Composable
private fun BranchesScreen(
    repoName: String,
    branches: List<LocalBranch>,
    dirtyCount: Int,
    busy: Boolean,
    error: String?,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onCheckout: (String) -> Unit,
    onDelete: (String) -> Unit,
    onCreate: (String) -> Unit,
) {
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf<String?>(null) }
    var confirmSwitch by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().background(Primer.BackgroundPrimary)
            .statusBarsPadding().navigationBarsPadding(),
    ) {
        SubPageHeader("分支 · $repoName", onBack) { RefreshButton { onRefresh() } }

        if (dirtyCount > 0) {
            Text(
                "工作区有 $dirtyCount 个改动；切换分支若会覆盖它们将被拒绝",
                fontSize = 11.5.sp,
                color = Primer.WarningTextStrong,
                lineHeight = 16.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Primer.WarningSurface)
                    .padding(10.dp),
            )
        }
        error?.let {
            Text(
                it,
                fontSize = 12.sp,
                color = Primer.Red500,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }

        LazyColumn(Modifier.weight(1f)) {
            items(branches) { b ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable(enabled = !b.isHead && !busy) {
                            if (dirtyCount > 0) confirmSwitch = b.name else onCheckout(b.name)
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (b.isHead) "●" else "○",
                        fontSize = 11.sp,
                        color = if (b.isHead) Primer.Green500 else Primer.TextTertiary,
                    )
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                b.name,
                                fontSize = 13.5.sp,
                                fontWeight = if (b.isHead) FontWeight.SemiBold else FontWeight.Normal,
                                color = Primer.TextPrimary,
                            )
                            if (b.isHead) {
                                Spacer(Modifier.width(6.dp))
                                Text("当前", fontSize = 10.sp, color = Primer.Green500)
                            }
                        }
                        val meta = buildString {
                            if (b.upstream.isNotBlank()) append(b.upstream)
                            if (b.ahead > 0) { if (isNotEmpty()) append(" · "); append("↑${b.ahead}") }
                            if (b.behind > 0) { if (isNotEmpty()) append(" · "); append("↓${b.behind}") }
                        }
                        if (meta.isNotBlank()) {
                            Text(meta, fontSize = 10.5.sp, color = Primer.TextTertiary, modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                    if (!b.isHead) {
                        val protected = isProtectedBranch(b.name)
                        Text(
                            "删除",
                            fontSize = 12.sp,
                            color = if (protected) Primer.TextTertiary else Primer.Red500,
                            modifier = Modifier.clickable(enabled = !protected && !busy) { confirmDelete = b.name },
                        )
                    }
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, Primer.Border, RoundedCornerShape(10.dp))
                        .clickable { showCreate = true }
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("＋ 新建分支", fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = Primer.Blue500)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("新建分支", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Primer.TextPrimary) },
            text = {
                Column {
                    Text(
                        "基于当前分支创建，创建后自动切换过去。",
                        fontSize = 12.sp, color = Primer.TextTertiary, lineHeight = 18.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        placeholder = { Text("分支名，如 feature/login", fontSize = 12.sp, color = Primer.TextTertiary) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = newName.isNotBlank() && !busy,
                    onClick = { val n = newName.trim(); showCreate = false; newName = ""; onCreate(n) },
                ) { Text("创建并切换", color = Primer.Blue500) }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("取消") } },
        )
    }

    confirmDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("删除分支 $target？", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Primer.TextPrimary) },
            text = {
                Text(
                    "只删除本地分支，不影响远端；未合并的提交会丢失。",
                    fontSize = 12.sp, color = Primer.TextTertiary, lineHeight = 18.sp,
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmDelete = null; onDelete(target) }) { Text("删除", color = Primer.Red500) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("取消") } },
        )
    }

    confirmSwitch?.let { target ->
        AlertDialog(
            onDismissRequest = { confirmSwitch = null },
            title = { Text("先撤销改动？", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Primer.TextPrimary) },
            text = {
                Text(
                    "工作区有 $dirtyCount 个改动，切换分支可能失败或覆盖它们。\n" +
                        "确认后会先撤销所有改动再切换（此操作不可撤销）。",
                    fontSize = 12.sp, color = Primer.TextTertiary, lineHeight = 18.sp,
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmSwitch = null; onCheckout(target) }) {
                    Text("撤销并切换", color = Primer.Red500)
                }
            },
            dismissButton = { TextButton(onClick = { confirmSwitch = null }) { Text("取消") } },
        )
    }
}

// ───────────────────────── 关于页 ─────────────────────────

/**
 * 关于页（**紧凑版**）：一屏看完「这是什么版本 / 是不是官方包 / 去哪儿反馈」。
 *
 * ## 旧版为什么显得空
 *
 * - 顶部把图标与文字**竖向堆叠**（80dp 图标 + 24/12/4/20 四段间距，约 150dp 只放了个 logo）；
 * - 信息行上下各 12dp 留白、行间没有分隔线，9 行版本信息占掉约 380dp；
 * - 校验结论在页面末尾又用一张独立横幅重复了一遍（横幅标题 + 说明 ≈ 70dp）；
 * - 段落间距 24 / 20 / 16 / 28 各来一次。
 * 加起来约 780dp —— 常见机型上要滑一屏半，而这一页真正要看的就是「版本 + 校验结论」。
 *
 * ## 紧凑版改了什么（内容一项没少）
 *
 * 1. **身份行**：图标 80 → 52dp，与名称同一行（名称 + 副标题右对齐成一列），
 *    右侧直接挂**校验结论胶囊** —— 结论从页尾横幅提前到第一屏第一眼；
 * 2. **信息行**：上下留白 12 → 8dp、行间补 1dp 分隔线（紧了也不会糊成一片），
 *    拆成「版本信息」「构建校验」两张卡片；
 * 3. **去重**：原独立横幅的「标题 + 说明」压成「胶囊短标签 + 一行说明」，说明并进校验卡片；
 * 4. 段落间距 24 / 20 / 16 / 28 → 统一 10dp（页尾 16dp）。
 *
 * 高度从约 780dp 降到约 590dp：常见机型**不用滚动**即可看全，
 * 版本 / 标准版本 / 构建时间 / 七位哈希 / Git 配置包 / 代码编辑器 /
 * 发布版本 / 签名校验 / 远程校验 / 校验说明 / 两个入口链接全部保留。
 */
@Composable
fun AboutScreen(onBack: () -> Unit) {
    LaunchedEffect(Unit) { Logger.ui("AboutScreen 进入，展示版本号与校验结果", "Compose") }
    val context = LocalContext.current
    val variant = remember { resolveReleaseVariant(context) }
    val localFingerprint = remember { signatureFingerprint(context) }
    var remoteFingerprint by remember { mutableStateOf<String?>(null) }
    var remoteChecking by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        remoteChecking = true
        remoteFingerprint = withContext(Dispatchers.IO) {
            val sig = when (variant) {
                ReleaseVariant.BETA -> fetchRemoteSignature("SunsetRNE", "Branchbase-Android", "beta", "verify/signature.txt")
                ReleaseVariant.RELEASE -> fetchLatestReleaseSignature("SunsetRNE", "Branchbase-Android")
                else -> null
            }
            sig?.let { parseSignatureFingerprint(it) }
        }
        remoteChecking = false
    }

    val state = buildVerifyState(
        variant = variant,
        localFingerprint = localFingerprint,
        remoteFingerprint = remoteFingerprint,
        checking = remoteChecking,
    )
    val copy = verifyCopy(state, variant, localFingerprint, remoteFingerprint)
    // 配色按状态取（绿=通过、红=不一致、蓝=进行中、琥珀=取不到远端、灰=本地编译）；
    // 底色走 Primer 的浅色块（深浅主题各自成立），描边由前景色降透明度推得，不再写死浅色 RGB
    val (fg, bg) = when (state) {
        BuildVerifyState.Checking -> Primer.Blue500 to Primer.InfoSurface
        BuildVerifyState.LocalBuild -> Primer.TextSecondary to Primer.Gray100
        BuildVerifyState.RemoteUnavailable -> Primer.WarningText to Primer.WarningSurface
        BuildVerifyState.Matched -> Primer.SuccessTextStrong to Primer.SuccessSurface
        BuildVerifyState.Mismatched -> Primer.Red500 to Primer.DangerSurface
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Primer.BackgroundPrimary).statusBarsPadding().navigationBarsPadding(),
    ) {
        SubPageHeader("关于", onBack)
        Column(
            // weight(1f)：与顶部 SubPageHeader 同级；fillMaxSize() 会超出容器，底部内容被压住
            modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
        ) {
            // 身份行：图标 + 名称/副标题 + 校验结论胶囊（原来结论在页尾横幅，这里第一眼就能看到）
            AboutIdentityRow(copy.chip, fg, bg)

            // 版本信息
            AboutCard(topGap = 10.dp) {
                AboutInfoRow("工程版本号", BuildConfig.ENGINEERING_VERSION)
                AboutRowDivider()
                AboutInfoRow("标准版本号", BuildConfig.STANDARD_VERSION)
                AboutRowDivider()
                AboutInfoRow("构建时间", BuildConfig.BUILD_TIME)
                AboutRowDivider()
                AboutInfoRow("七位哈希", BuildConfig.GIT_HASH)
                AboutRowDivider()
                AboutInfoRow("Git 配置包", "libgit2 1.7.2")
                AboutRowDivider()
                // 第三方代码编辑器痕迹：独立模块 :editor 封装，移除时删这行 + 该模块
                AboutInfoRow(
                    "代码编辑器",
                    "${com.branchbase.editor.EditorModuleInfo.NAME} " +
                        "${com.branchbase.editor.EditorModuleInfo.VERSION}（${com.branchbase.editor.EditorModuleInfo.MODULE}）",
                )
            }

            // 构建校验：三行原始值 + 一行结论说明（原独立横幅的去重落点）
            AboutCard(topGap = 10.dp) {
                AboutInfoRow("发布版本", variant.label)
                AboutRowDivider()
                AboutInfoRow("签名校验", if (variant != ReleaseVariant.UNKNOWN) "匹配" else "异常（未知签名）")
                AboutRowDivider()
                AboutInfoRow(
                    "远程校验",
                    when {
                        remoteChecking -> "校验中…"
                        remoteFingerprint.isNullOrBlank() -> "无法获取校验文件"
                        remoteFingerprint.equals(localFingerprint, ignoreCase = true) -> "匹配"
                        else -> "不匹配"
                    },
                )
                AboutRowDivider()
                AboutVerifyNote(copy.detail, fg)
            }

            // 项目主页 + 开发交流群：关于页是用户找「去哪儿反馈」的地方，链接统一从这里出去。
            // QQ 群链接里的 authKey 会过期，所以群号也直接写在行里（过期了按号搜索即可）。
            AboutCard(topGap = 10.dp) {
                AboutLinkRow("项目主页（仅 Android）", "SunsetRNE/Branchbase-Android") {
                    openExternal(context, REPO_URL)
                }
                AboutRowDivider()
                AboutLinkRow("开发交流（QQ 群）", "790735040") {
                    openExternal(context, QUN_URL)
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

/** 身份行：52dp 图标 + 名称/副标题 + 右侧校验结论胶囊。 */
@Composable
private fun AboutIdentityRow(chip: String, fg: Color, bg: Color) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // 应用图标：与桌面完全一致的那枚（PackageManager 合成自适应图标两个图层；
        // 曾经的手搓近似只画 foreground + 硬编码 #0d1117，与真实图标并不一致，已移除）。
        // 紧凑版缩到 52dp 并与文字同行 —— 关于页的图标是识别用的，不需要占掉 1/5 屏。
        AppIcon(size = 52.dp, shape = RoundedCornerShape(14.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Branchbase", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Primer.TextPrimary)
            Spacer(Modifier.height(2.dp))
            Text("GitHub 第三方客户端", fontSize = 11.5.sp, color = Primer.TextTertiary)
        }
        Spacer(Modifier.width(8.dp))
        Text(
            chip,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier
                .clip(RoundedCornerShape(9.dp))
                .background(bg)
                .border(1.dp, fg.copy(alpha = 0.30f), RoundedCornerShape(9.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
}

/** 关于页卡片容器（16dp 页边距 + 8dp 圆角 + 描边；与设置页列表同一套观感）。 */
@Composable
private fun AboutCard(topGap: Dp, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = topGap)
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, Primer.Border, RoundedCornerShape(8.dp)),
        content = content,
    )
}

/** 卡片内行间分隔线（紧凑版行距只有 8dp，没有它几行会糊成一块）。 */
@Composable
private fun AboutRowDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Primer.Border))
}

/** 校验说明行（原横幅的 detail）：小字 + 状态色，跟着校验卡片走。 */
@Composable
private fun AboutVerifyNote(text: String, fg: Color) {
    Text(
        text,
        fontSize = 11.5.sp,
        color = fg.copy(alpha = 0.9f),
        lineHeight = 16.sp,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

/** 项目主页（仓库地址，同时说明只做 Android）。 */
private const val REPO_URL = "https://github.com/SunsetRNE/Branchbase-Android"

/**
 * 开发交流 QQ 群的加群链接（群「Branchbase开发交流」· 790735040）。
 *
 * ⚠️ 链接里的 `authKey` / `data` 是腾讯签发的**会过期**的票据：过期后这个链接会失效，
 * 所以界面上把群号一并显示出来，过期了按群号搜索同样能进群。
 */
private const val QUN_URL =
    "https://qun.qq.com/universal-share/share?ac=1&authKey=pvJE5SaHMaTeBU%2BNqt2VJBfeAGY0eLg%2BGHUTz2TDjsxe0aeS3L32m6Cg0NEnMCmg" +
        "&busi_data=eyJncm91cENvZGUiOiI3OTA3MzUwNDAiLCJ0b2tlbiI6ImN4bGZ6WnBiUHVRZ0JOWFlmTVloV1R6S1o3NnIyV212RExzeTdtdUs4TVdqamVaNjR0V2xDRGJvNkI1N1RvV3ciLCJ1aW4iOiIxNTM5MDA3NDYwIn0%3D" +
        "&data=U0Umjl8BD3SwVhcezyilAhDNcA1MUL3HSJAq3dI4hCfZywecQmAbK4yqvgp-3FkggT-Sq4hqJivTho3p4TrhEQ&svctype=4&tempid=h5_group_info"

/** 用系统浏览器（或能处理该 scheme 的应用）打开外部链接；失败就静默忽略（不崩）。 */
private fun openExternal(context: android.content.Context, url: String) {
    runCatching {
        context.startActivity(
            android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)),
        )
    }
}

/** 关于页的可点击链接行（标题 + 右侧值 + `›`）；上下 12dp 保住 ~41dp 的点击高度。 */
@Composable
private fun AboutLinkRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, fontSize = 13.sp, color = Primer.TextSecondary, maxLines = 1)
        Spacer(Modifier.width(10.dp))
        // 值占满剩余宽度并右对齐：窄屏上由它省略（而不是让标题被挤掉或整行溢出）
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Primer.Blue500,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f),
        )
        Spacer(Modifier.width(4.dp))
        Text("›", fontSize = 14.sp, color = Primer.TextTertiary)
    }
}

@Composable
private fun AboutInfoRow(key: String, value: String) {
    Row(
        // 上下 8dp（原 12dp）：紧凑版行距收紧，靠行间 1dp 分隔线区分，
        // 又不至于把可读性压没（12.5sp 正文 + 8dp 留白 ≈ 33dp 行高）
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(key, fontSize = 12.5.sp, color = Primer.TextSecondary)
        Spacer(Modifier.width(12.dp))
        Text(
            value,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = Primer.TextPrimary,
            textAlign = TextAlign.End,
            // 值占满剩余宽度并右对齐：标准版本号（版本-时间-哈希）较长，窄屏允许折行而不是被省略
            modifier = Modifier.weight(1f),
        )
    }
}

/**
 * 仓库关系徽章（账号仓库 / 协作仓库 / 非账号仓库 / 非协作仓库）。
 *
 * 颜色按「能不能写」分档：能写的用绿色（与提交/推送入口一致），只能读的用中性灰，
 * 无权限的用红色 —— 一眼看出这个仓库我能做什么。
 */
@Composable
internal fun RepoRelationBadge(relation: RepoRelation?, modifier: Modifier = Modifier) {
    if (relation == null) return
    val (fg, bg) = when (relation) {
        RepoRelation.OWN, RepoRelation.COLLABORATOR -> Primer.SuccessText to Primer.SuccessSurface
        RepoRelation.FOREIGN -> Primer.TextTertiary to Primer.Gray150
        RepoRelation.NOT_COLLABORATOR -> Primer.Red500 to Primer.DangerSurface
    }
    Text(
        relation.label,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = fg,
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 5.dp, vertical = 1.dp),
    )
}
