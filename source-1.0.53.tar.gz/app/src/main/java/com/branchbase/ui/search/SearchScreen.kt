package com.branchbase.ui.search

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.branchbase.ui.repository.RepoDeepLink
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.branchbase.ui.repository.RepoRelation
import com.branchbase.ui.repository.repoRelationOf
import com.branchbase.ui.theme.ProvideShimmer
import com.branchbase.ui.theme.skeletonBlock
import com.branchbase.cache.SearchCacheDatabase
import com.branchbase.cache.SearchCacheManager
import com.branchbase.core.RustBridge
import com.branchbase.ui.log.Logger
import com.branchbase.ui.theme.iconTap
import com.branchbase.ui.theme.CodeSyntax
import com.branchbase.ui.theme.Primer
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * 搜索界面（参考 GitHub 网页版三层结构）。
 *
 * 搜索框 / 工具栏（类型下拉+排序下拉+过滤）/ 结果列表 / 过滤面板。
 */
@Composable
fun SearchScreen(
    sessionJson: String,
    onBack: () -> Unit,
    /**
     * 站内跳转（仓库 / issue / PR / 提交 / 文件）。
     *
     * 走的与「通知深链接」同一条路由（`RepoDeepLink` → `MainScreen` 的仓库路由），
     * 因此落点与返回栈行为完全一致，搜索结果页不需要自己拼导航。
     */
    onOpenInApp: (RepoDeepLink) -> Unit,
) {
    LaunchedEffect(Unit) { Logger.ui("进入搜索页", "Compose") }
    val token = runCatching { JSONObject(sessionJson).getJSONObject("token").optString("access_token") }.getOrNull() ?: ""
    val host = runCatching { JSONObject(sessionJson).optString("host", "github.com") }.getOrDefault("github.com")

    val context = LocalContext.current
    val cacheManager = remember {
        val db = SearchCacheDatabase.getInstance(context)
        SearchCacheManager(db.searchCacheDao())
    }

    val scope = rememberCoroutineScope()

    /**
     * 搜索词 / 类型 / 排序 / 筛选存在 ViewModel 里（不是 `remember`）：
     * 点进某个结果再返回时，搜索页会被销毁重建，放 `remember` 会全部归零。
     */
    val vm: SearchViewModel = viewModel()
    var query by vm.queryState
    var selectedLanguage by vm.languageState
    var advancedValues by vm.advancedState
    var type by vm.typeState
    var sort by vm.sortState
    var sortKey by vm.sortKeyState
    var searched by vm.searchedState

    // 纯界面态（气泡/面板是否展开）留在这里即可
    var expandedFilter by remember { mutableStateOf<String?>(null) }
    var typeMenu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var showFilter by remember { mutableStateOf(false) }

    // 结果本身不进 ViewModel：返回时按缓存直出（命中即瞬时），避免在内存里留一份大对象
    var results by remember { mutableStateOf<List<SearchItem>>(emptyList()) }
    var codeResults by remember { mutableStateOf<List<CodeResult>>(emptyList()) }
    var pullResults by remember { mutableStateOf<List<PullResult>>(emptyList()) }
    var commitResults by remember { mutableStateOf<List<CommitResult>>(emptyList()) }
    var topicResults by remember { mutableStateOf<List<TopicResult>>(emptyList()) }
    var total by remember { mutableStateOf(0L) }
    // 分页：已拿到的页码 + 是否正在加载下一页（与首屏 loading 分开，底部只转小圈）
    var page by remember { mutableStateOf(1) }
    var loadingMore by remember { mutableStateOf(false) }
    // 返回页面时会自动重搜，先亮加载态，避免闪一帧「未找到结果」
    var loading by remember { mutableStateOf(vm.hasPendingSession()) }
    var searchError by remember { mutableStateOf<String?>(null) }

    // 缓存键要绑账号：搜索结果含私有仓库/私有代码，跨账号命中既是错误结果也是权限泄漏
    val login = remember(sessionJson, context) {
        runCatching { JSONObject(sessionJson).getJSONObject("user").optString("login") }
            .getOrNull()?.takeIf { it.isNotBlank() && it != "null" }
            ?: com.branchbase.core.AccountStore.currentLogin(context)
    }

    fun doSearch() {
        // ① 请求发起时把条件**快照**下来：协程恢复时用户可能已经改了类型/排序，
        //    那时再读 type/results 会把 A 类型的结果按 B 类型解析、写进 B 的状态桶
        val query0 = query
        if (query0.isBlank()) return
        val type0 = type
        val sortKey0 = sortKey
        val q = buildSearchQuery(query0, type0, selectedLanguage, advancedValues, advancedFilters)
        val cacheKey = searchCacheKey(type0, query0, sortKey0, login)

        // ② 统一解析并写入对应类型状态（按快照里的类型）
        fun parseAndSet(json: String) {
            when (type0) {
                "代码" -> { val p = parseCodeResults(json); codeResults = p.first; total = p.second }
                "拉取请求" -> { val p = parsePullResults(json); pullResults = p.first; total = p.second }
                "提交" -> { val p = parseCommitResults(json); commitResults = p.first; total = p.second }
                "主题" -> { val p = parseTopicResults(json); topicResults = p.first; total = p.second }
                else -> { val p = parseResults(json, type0, me = login); results = p.first; total = p.second }
            }
        }

        // ③ 仓库搜索：预加载前几个结果的详情（点进去直接命中缓存；计费网络自动跳过）
        fun warmRepos(found: List<SearchItem>) {
            if (type0 != "仓库") return
            com.branchbase.cache.RepoPrefetcher.warmList(
                context = context,
                host = host,
                token = token,
                // 仓库结果的 title 就是 full_name（见 parseResults）
                entries = found.map {
                    it.title.substringBefore('/') to it.title.substringAfter('/', "")
                },
            )
        }

        // ④ 请求序号：快速连点 / 改条件后再搜时，旧响应后到就丢弃（否则会覆盖新结果、提前收掉转圈）
        val token0 = vm.nextSeq()
        page = 1
        loading = true
        searchError = null
        scope.launch {
            // 命中缓存：读本地数据库
            val cached = cacheManager.get(cacheKey, type0)
            if (cached != null) {
                if (!vm.isCurrent(token0)) return@launch
                parseAndSet(cached)
                searched = true
                loading = false
                warmRepos(results)
                return@launch
            }

            // 未命中：拉远端并写缓存
            val json = when (type0) {
                "代码" -> RustBridge.searchCode(host, token, q)
                "仓库" -> RustBridge.searchRepositories(host, token, q, sortKey)
                "用户" -> RustBridge.searchUsers(host, token, q)
                "议题", "拉取请求" -> RustBridge.searchIssues(host, token, q)
                "提交" -> RustBridge.searchCommits(host, token, q)
                "主题" -> RustBridge.searchTopics(host, token, q)
                else -> null
            }
            // 回来时若不是最新一次搜索：整份结果丢弃（连 loading 都不要动，那是新请求的）
            if (!vm.isCurrent(token0)) return@launch

            Logger.net("搜索 $type0: $q → ${if (json != null && !json.startsWith("ERROR:")) "200" else "失败"}", "search")
            if (json != null && !json.startsWith("ERROR:")) {
                // 先立即用拉取结果填充展示，再异步写入缓存（更新缓存与展示同源、同步发生）
                parseAndSet(json)
                page = 1
                cacheManager.put(cacheKey, type0, json)
                searched = true
                warmRepos(results)
            } else {
                // 搜索失败（网络错误 / 速率限制 / 权限不足等），区别于「无结果」
                searched = true
                searchError = friendlySearchError(json)
            }
            loading = false
        }
    }

    // 从结果进详情再返回：搜索词与条件还在（ViewModel），这里按缓存直出结果
    LaunchedEffect(Unit) {
        if (vm.hasPendingSession()) doSearch()
    }

    /** 当前类型的已展示条数（分页推进与「已到底」判断共用）。 */
    fun shownCount(): Int = when (type) {
        "代码" -> codeResults.size
        "拉取请求" -> pullResults.size
        "提交" -> commitResults.size
        "主题" -> topicResults.size
        else -> results.size
    }

    /**
     * 解析并把新一页**追加**到对应列表（按 key 去重）。返回本页新增条数。
     *
     * 去重是必须的：GitHub 分页在数据变动时会出现同一项跨页重复（按 stars/updated 排序时尤其常见）。
     */
    fun appendPage(json: String, type0: String): Int = when (type0) {
        "代码" -> {
            val p = parseCodeResults(json)
            val before = codeResults.size
            codeResults = mergePage(codeResults, p.first) { "${it.owner}/${it.repository}/${it.path}" }
            total = maxOf(total, p.second)
            codeResults.size - before
        }
        "拉取请求" -> {
            val p = parsePullResults(json)
            val before = pullResults.size
            pullResults = mergePage(pullResults, p.first) { "${it.repository}#${it.number}" }
            total = maxOf(total, p.second)
            pullResults.size - before
        }
        "提交" -> {
            val p = parseCommitResults(json)
            val before = commitResults.size
            commitResults = mergePage(commitResults, p.first) { it.sha }
            total = maxOf(total, p.second)
            commitResults.size - before
        }
        "主题" -> {
            val p = parseTopicResults(json)
            val before = topicResults.size
            topicResults = mergePage(topicResults, p.first) { it.name }
            total = maxOf(total, p.second)
            topicResults.size - before
        }
        else -> {
            val p = parseResults(json, type0, me = login)
            val before = results.size
            // 用定位信息当 key（标题会误伤不同仓库里的同名 issue，见 searchItemKey 说明）
            results = mergePage(results, p.first) { searchItemKey(it.target, it.title) }
            total = maxOf(total, p.second)
            results.size - before
        }
    }

    /**
     * 加载下一页（追加到现有列表）。
     *
     * ## 为什么不自动触发
     *
     * 搜索类接口的限额很紧（代码搜索约 10 次/分钟），滚到底自动翻页会让用户
     * 「只是滑两下」就撞上限流。这里做成**显式按钮**，并在按钮上写清「已显示 N / 共 M」，
     * 用户自己决定要不要继续 —— 与被限流时的提示（第 ⑤ 条）配套。
     *
     * ## 与首屏请求的关系
     *
     * 共用同一份条件快照与同一个请求序号：加载途中用户改了条件并重新搜索时，
     * 这一页的结果会因为序号过期而丢弃，不会把旧查询的第 2 页追加到新结果里。
     */
    fun loadMore() {
        if (loadingMore || loading) return
        val query0 = query
        val type0 = type
        val sortKey0 = sortKey
        if (query0.isBlank()) return
        val q = buildSearchQuery(query0, type0, selectedLanguage, advancedValues, advancedFilters)
        val next = nextPage(page, shownCount())
        val token0 = vm.nextSeq()

        loadingMore = true
        scope.launch {
            val json = when (type0) {
                "代码" -> RustBridge.searchCode(host, token, q, next)
                "仓库" -> RustBridge.searchRepositories(host, token, q, sortKey0, next)
                "用户" -> RustBridge.searchUsers(host, token, q, next)
                "议题", "拉取请求" -> RustBridge.searchIssues(host, token, q, next)
                "提交" -> RustBridge.searchCommits(host, token, q, next)
                "主题" -> RustBridge.searchTopics(host, token, q, next)
                else -> null
            }
            loadingMore = false
            // 序号过期（期间有更新的搜索）：整份丢弃
            if (!vm.isCurrent(token0)) return@launch
            if (json == null || json.startsWith("ERROR:")) {
                searchError = friendlySearchError(json)
                // 翻到 GitHub 的 1000 条上限：把总量收敛到已展示数，底部按钮随之收掉，
                // 不然用户会对着一个永远失败的按钮反复点。
                if (searchResultCapReached(json)) total = shownCount().toLong()
                return@launch
            }
            val received = appendPage(json, type0)
            page = next
            // 服务端返回的 total 比总量小 / 本页为空 → 视为到底（避免按钮一直转）
            if (received <= 0) total = shownCount().toLong()
            Logger.net("搜索 $type0 第 $next 页：+$received 条", "search")
        }
    }

    /** 结果列表底部：加载更多 / 加载中 / 已到底（五种结果类型共用一份页脚）。 */
    fun LazyListScope.pagingFooter(shown: Int) {
        item(key = "paging-footer") {
            SearchPagingFooter(
                shown = shown,
                total = total,
                loadingMore = loadingMore,
                onLoadMore = { loadMore() },
            )
        }
    }

    /**
     * 结果点击派发：**站内有页面的走站内**（仓库 / issue / PR / 提交 / 文件），
     * 站内没有页面的（用户主页 / 主题页）交给浏览器。
     */
    fun openTarget(target: SearchTarget?) {
        when (target) {
            null -> Unit
            is SearchTarget.Web -> runCatching {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target.url)))
            }
            else -> target.toRepoDeepLink()?.let(onOpenInApp)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Primer.BackgroundPrimary)
            .statusBarsPadding(),
    ) {
        // 搜索框
        SearchTopBar(query = query, onQueryChange = { query = it }, onSearch = { doSearch() }, onBack = onBack)

        // 工具栏
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // 类型下拉
            Box(Modifier.weight(1f)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth().height(40.dp)
                        .clip(RoundedCornerShape(8.dp)).background(Primer.BackgroundSecondary)
                        .clickable { typeMenu = true }.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(type, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary, modifier = Modifier.weight(1f))
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = Primer.IconSecondary, modifier = Modifier.size(18.dp))
                }
                // 白底 + Primer 描边：主题已把容器角色统一成标准白底，
                // 这里再补一道描边，与 App 其它弹层（气泡 / 手板）的「白底 + 描边 + 阴影」一致
                DropdownMenu(
                    expanded = typeMenu,
                    onDismissRequest = { typeMenu = false },
                    containerColor = Primer.BackgroundPrimary,
                    border = BorderStroke(1.dp, Primer.Border.copy(alpha = 0.5f)),
                ) {
                    types.forEach { t ->
                        DropdownMenuItem(
                            text = { Text(t, fontSize = 13.sp, color = Primer.TextPrimary) },
                            onClick = { type = t; typeMenu = false },
                        )
                    }
                }
            }
            // 排序下拉（仅仓库搜索支持排序，其余类型隐藏）
            if (type == "仓库") {
                Box {
                    Row(
                        modifier = Modifier
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp)).background(Primer.BackgroundSecondary)
                            .clickable { sortMenu = true }.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(sort, fontSize = 12.sp, color = Primer.TextSecondary)
                        Spacer(Modifier.width(2.dp))
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = Primer.IconSecondary, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = sortMenu,
                        onDismissRequest = { sortMenu = false },
                        containerColor = Primer.BackgroundPrimary,
                        border = BorderStroke(1.dp, Primer.Border.copy(alpha = 0.5f)),
                    ) {
                        sortOptions.forEach { (key, label) ->
                            DropdownMenuItem(
                                text = { Text(label, fontSize = 13.sp, color = Primer.TextPrimary) },
                                onClick = {
                                    sort = label; sortKey = key; sortMenu = false
                                    if (searched) doSearch()
                                },
                            )
                        }
                    }
                }
            }
            // 过滤按钮
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Primer.BackgroundSecondary)
                    .clickable { showFilter = true },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Tune, contentDescription = "过滤", tint = Primer.IconPrimary, modifier = Modifier.size(20.dp))
            }
        }

        // 结果
        if (loading) {
            SearchSkeleton()
        } else if (searchError != null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(searchError!!, color = Primer.Red500)
            }
        } else if (!searched) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("输入关键词搜索", color = Primer.TextTertiary)
            }
        } else if (type == "代码") {
            if (codeResults.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("未找到匹配的代码", color = Primer.TextTertiary)
                }
            } else {
                Column {
                    Text(resultCountText(total, codeResults.size, "代码结果"), fontSize = 12.sp, color = Primer.TextTertiary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                    LazyColumn {
                        items(codeResults) { code -> CodeResultCard(code) { openTarget(code.target) } }
                        pagingFooter(codeResults.size)
                    }
                }
            }
        } else if (type == "拉取请求") {
            if (pullResults.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("未找到匹配的拉取请求", color = Primer.TextTertiary)
                }
            } else {
                Column {
                    Text(resultCountText(total, pullResults.size, "拉取请求结果"), fontSize = 12.sp, color = Primer.TextTertiary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                    LazyColumn {
                        items(pullResults) { pull -> PullCard(pull) { openTarget(pull.target) } }
                        pagingFooter(pullResults.size)
                    }
                }
            }
        } else if (type == "提交") {
            if (commitResults.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("未找到匹配的提交", color = Primer.TextTertiary)
                }
            } else {
                Column {
                    Text(resultCountText(total, commitResults.size, "提交结果"), fontSize = 12.sp, color = Primer.TextTertiary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                    LazyColumn {
                        items(commitResults) { commit -> CommitCard(commit) { openTarget(commit.target) } }
                        pagingFooter(commitResults.size)
                    }
                }
            }
        } else if (type == "主题") {
            if (topicResults.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("未找到匹配的主题", color = Primer.TextTertiary)
                }
            } else {
                Column {
                    Text(resultCountText(total, topicResults.size, "主题结果"), fontSize = 12.sp, color = Primer.TextTertiary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                    LazyColumn {
                        item { TopicCard(topicResults) { openTarget(it.target) } }
                        pagingFooter(topicResults.size)
                    }
                }
            }
        } else if (results.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("未找到匹配结果", color = Primer.TextTertiary)
            }
        } else {
            Column {
                Text(resultCountText(total, results.size, "结果"), fontSize = 12.sp, color = Primer.TextTertiary, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                LazyColumn {
                    items(results) { item -> SearchItemCard(item) { openTarget(item.target) } }
                    pagingFooter(results.size)
                }
            }
        }
    }

    if (showFilter) {
        FilterSheet(
            selectedLanguage = selectedLanguage,
            onSelectLanguage = { lang ->
                selectedLanguage = lang
                showFilter = false
                doSearch()
            },
            advancedValues = advancedValues,
            expandedFilter = expandedFilter,
            onToggleFilter = { name -> expandedFilter = if (expandedFilter == name) null else name },
            onApplyFilter = { name, value ->
                advancedValues = advancedValues + (name to value)
                expandedFilter = null
            },
            onDismiss = { showFilter = false },
        )
    }
}

/** 搜索框 */
@Composable
private fun SearchTopBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    onBack: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 8.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回", tint = Primer.IconPrimary, modifier = Modifier.size(24.dp).iconTap { onBack() })
        Spacer(Modifier.width(4.dp))
        Box(
            modifier = Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(8.dp)).background(Primer.BackgroundSecondary).padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = TextStyle(fontSize = 14.sp, color = Primer.TextPrimary),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    if (query.isEmpty()) {
                        Text("搜索或跳转", fontSize = 14.sp, color = Primer.TextTertiary)
                    }
                    inner()
                },
            )
        }
        Spacer(Modifier.width(8.dp))
        Icon(Icons.Filled.Search, contentDescription = "搜索", tint = Primer.Blue500, modifier = Modifier.size(22.dp).iconTap { onSearch() })
    }
}

/** 搜索加载骨架屏（shimmer 呼吸） */
@Composable
private fun SearchSkeleton() {
    // 微光规格收在 ui/theme/Motion.kt（通知页骨架用同一份）。
    // ProvideShimmer 包在 repeat 外面：整屏一条动画；占位块用 skeletonBlock，
    // alpha 在绘制期读 —— 以前是每个占位块 `background(color.copy(alpha = alpha))`，
    // 等于把 15 个占位块都挂到动画的每一帧上，加载时每帧重组一遍。
    ProvideShimmer {
        Column {
            repeat(5) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Primer.BackgroundSecondary)
                        .padding(14.dp),
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(0.55f)
                            .height(16.dp)
                            .skeletonBlock(),
                    )
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .skeletonBlock(),
                    )
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier
                            .fillMaxWidth(0.7f)
                            .height(12.dp)
                            .skeletonBlock(),
                    )
                }
            }
        }
    }
}

/** 搜索结果卡片 */
@Composable
private fun SearchItemCard(item: SearchItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Primer.BackgroundSecondary)
            .clickable(onClick = onClick)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(item.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Primer.Blue500)
            // 「我的」徽章：搜索结果里一眼分出账号仓库与别人的仓库（搜索接口不返回 permissions，
            // 所以只判定「是不是我自己的」，协作/只读关系在仓库详情页才准）
            if (item.relation == RepoRelation.OWN) {
                Spacer(Modifier.width(6.dp))
                Text(
                    "我的",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Primer.SuccessText,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Primer.SuccessSurface)
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                )
            }
        }
        if (item.subtitle.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(item.subtitle, fontSize = 13.sp, color = Primer.TextSecondary)
        }
        if (item.meta != null) {
            Spacer(Modifier.height(8.dp))
            Text(item.meta, fontSize = 12.sp, color = Primer.TextTertiary)
        }
    }
}

/** 代码搜索结果卡片（对标 GitHub 网页：仓库路径 + 文件路径胶囊 + 代码片段 + 次级路径 + 折叠提示） */
@Composable
private fun CodeResultCard(code: CodeResult, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .border(1.dp, CodeSyntax.CardBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
    ) {
        // ① 仓库路径行：头像（Coil 加载，无则首字母兜底）+ owner/repo + 下拉箭头
        Row(
            modifier = Modifier.fillMaxWidth().background(CodeSyntax.CodeBg).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (code.avatarUrl != null) {
                AsyncImage(
                    model = code.avatarUrl,
                    contentDescription = code.owner,
                    modifier = Modifier.size(20.dp).clip(CircleShape),
                )
            } else {
                Box(Modifier.size(20.dp).clip(CircleShape).background(Primer.Border), contentAlignment = Alignment.Center) {
                    Text(code.owner.take(1).uppercase(), fontSize = 9.sp, color = Primer.IconPrimary)
                }
            }
            Spacer(Modifier.width(8.dp))
            Text(code.repository, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = Primer.IconSecondary, modifier = Modifier.size(14.dp))
        }
        // ② 文件路径行：展开箭头 + 文件名 + 语言胶囊 + Matches 胶囊
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Primer.IconSecondary, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(code.fileName, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
            Spacer(Modifier.weight(1f))
            if (code.language != null) {
                LanguagePill(code.language)
                Spacer(Modifier.width(6.dp))
            }
            MatchCountPill(code.matchCount)
        }
        // ③ 代码片段块（片段相对行号 + 语法高亮 + 匹配词黄底）
        CodeBlock(code.fragment, code.matches)
        // ④ 次级文件路径（同 sha 分组）
        if (code.subPaths.isNotEmpty()) {
            Column(Modifier.fillMaxWidth()) {
                code.subPaths.forEach { sub ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 40.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(fileIcon(sub), contentDescription = null, tint = Primer.Blue500, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(sub, fontSize = 12.sp, color = Primer.TextSecondary)
                    }
                }
            }
        }
        // ⑤ 折叠提示
        if (code.subPaths.size > 3) {
            Row(
                Modifier.fillMaxWidth().background(CodeSyntax.CodeBg).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Text("⚠", fontSize = 11.sp, color = Primer.TextTertiary)
                Spacer(Modifier.width(6.dp))
                Text("仅显示包含此内容的部分文件路径。优化搜索以查看更多。", fontSize = 11.sp, color = CodeSyntax.Comment)
            }
        }
    }
}

/** 代码片段块：片段相对行号 + 语法高亮 + 匹配词黄底 */
@Composable
private fun CodeBlock(fragment: String, matches: List<MatchRange>) {
    val lines = fragment.split('\n')
    Column(Modifier.fillMaxWidth().background(CodeSyntax.CodeBg).padding(vertical = 6.dp)) {
        var offset = 0
        lines.forEachIndexed { idx, line ->
            // 把落在本行的匹配词转成相对本行的偏移
            val local = matches.mapNotNull { m ->
                val start = m.start - offset
                val end = m.end - offset
                if (start >= 0 && end <= line.length && start < end) MatchRange(m.text, start, end) else null
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Text(
                    (idx + 1).toString(),
                    color = CodeSyntax.LineNo,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.End,
                    modifier = Modifier.width(34.dp),
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    buildCodeText(line, local),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = Primer.TextPrimary,
                )
            }
            offset += line.length + 1
        }
    }
}

/** 语言胶囊（语言色点 + 语言名） */
@Composable
private fun LanguagePill(language: String) {
    Row(
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).border(1.dp, CodeSyntax.CardBorder, RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(langColor(language)))
        Spacer(Modifier.width(5.dp))
        Text(language, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextSecondary)
    }
}

/** 匹配数胶囊 */
@Composable
private fun MatchCountPill(count: Int) {
    Row(
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).border(1.dp, CodeSyntax.CardBorder, RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(Primer.Border))
        Spacer(Modifier.width(5.dp))
        Text("匹配 $count 处", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextSecondary)
    }
}

/** 拉取请求结果卡片（状态徽章 + 标题 + 编号 + 仓库） */
@Composable
private fun PullCard(pull: PullResult, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Primer.BackgroundSecondary)
            .clickable(onClick = onClick)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusBadge(pull)
            Spacer(Modifier.width(8.dp))
            Text(pull.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Primer.Blue500)
        }
        Spacer(Modifier.height(8.dp))
        Text("#${pull.number} · ${pull.repository}", fontSize = 12.sp, color = Primer.TextTertiary)
    }
}

/**
 * 状态徽章（open/merged/closed）。
 *
 * `Open` 早就用了主题角色（`SuccessText`），只有 merged / closed 还写死浅色取值 ——
 * 现在三者都走角色（`Purple500` = `done`、`Red500` = `danger`）。
 */
@Composable
private fun StatusBadge(pull: PullResult) {
    val (text, color) = when {
        pull.merged -> "Merged" to Primer.Purple500
        pull.state == "open" -> "Open" to Primer.SuccessText
        else -> "Closed" to Primer.Red500
    }
    Text(
        text,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = Color.White,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(color).padding(horizontal = 8.dp, vertical = 2.dp),
    )
}

/** 提交结果卡片（提交信息 + sha + 作者 + 仓库） */
@Composable
private fun CommitCard(commit: CommitResult, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Primer.BackgroundSecondary)
            .clickable(onClick = onClick)
            .padding(14.dp),
    ) {
        Text(commit.message, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clip(RoundedCornerShape(4.dp)).background(Primer.Gray150).padding(horizontal = 6.dp, vertical = 1.dp)) {
                Text(commit.sha.take(7), fontSize = 12.sp, color = Primer.TextSecondary, fontFamily = FontFamily.Monospace)
            }
            Spacer(Modifier.width(8.dp))
            Text(commit.author, fontSize = 12.sp, color = Primer.TextTertiary)
            Spacer(Modifier.width(8.dp))
            Text(commit.repository, fontSize = 12.sp, color = Primer.TextTertiary)
        }
    }
}

/** 主题结果卡片（chip 网格） */
@Composable
private fun TopicCard(topics: List<TopicResult>, onTopicClick: (TopicResult) -> Unit) {
    Column(
        modifier = Modifier
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Primer.BackgroundSecondary)
            .padding(14.dp),
    ) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            topics.forEach { topic ->
                Text(
                    topic.name,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Primer.Blue500,
                    // clip 在 clickable 之前：点击反馈跟随圆角；点一下去官方主题页
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Primer.Gray150)
                        .clickable { onTopicClick(topic) }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                )
            }
        }
    }
}

/** 根据文件扩展名返回文件类型图标 */
private fun fileIcon(path: String): ImageVector {
    val ext = path.substringAfterLast('.', "").lowercase()
    return when (ext) {
        "md", "markdown", "txt", "rst" -> Icons.Filled.Description
        "json", "xml", "yaml", "yml", "toml" -> Icons.Filled.DataObject
        else -> Icons.AutoMirrored.Filled.InsertDriveFile
    }
}

/** 构建带语法高亮的代码文本（匹配词 + 注释 + 字符串 + 关键字 + 函数 + 数字，对标 GitHub light theme） */
@Composable
private fun buildCodeText(fragment: String, matches: List<MatchRange>): AnnotatedString {
    return buildAnnotatedString {
        var i = 0
        val sorted = matches.sortedBy { it.start }
        var matchIdx = 0
        while (i < fragment.length) {
            // 匹配词高亮（优先级最高，黄底文字保持原色）
            if (matchIdx < sorted.size && sorted[matchIdx].start == i) {
                val m = sorted[matchIdx]
                val start = m.start.coerceIn(0, fragment.length)
                val end = m.end.coerceIn(start, fragment.length)
                pushStyle(SpanStyle(background = CodeSyntax.MatchBg))
                append(fragment.substring(start, end))
                pop()
                i = end
                matchIdx++
                continue
            }
            val c = fragment[i]
            // 行注释（灰斜体）
            if (c == '/' && i + 1 < fragment.length && fragment[i + 1] == '/') {
                val nl = fragment.indexOf('\n', i)
                val end = if (nl == -1) fragment.length else nl
                pushStyle(SpanStyle(color = CodeSyntax.Comment, fontStyle = FontStyle.Italic))
                append(fragment.substring(i, end))
                pop()
                i = end
                continue
            }
            // 字符串（蓝）
            if (c == '"' || c == '\'') {
                val end = findStringEnd(fragment, i, c)
                pushStyle(SpanStyle(color = CodeSyntax.StringLit))
                append(fragment.substring(i, end))
                pop()
                i = end
                continue
            }
            // 数字（蓝）
            if (c.isDigit()) {
                var j = i
                while (j < fragment.length && (fragment[j].isDigit() || fragment[j] == '.')) j++
                pushStyle(SpanStyle(color = CodeSyntax.Number))
                append(fragment.substring(i, j))
                pop()
                i = j
                continue
            }
            // 标识符：函数（紫）/ 关键字（红）
            if (c.isLetter() || c == '_') {
                var j = i
                while (j < fragment.length && (fragment[j].isLetterOrDigit() || fragment[j] == '_')) j++
                val word = fragment.substring(i, j)
                val isFn = j < fragment.length && fragment[j] == '('
                when {
                    isFn -> {
                        pushStyle(SpanStyle(color = CodeSyntax.Function))
                        append(word)
                        pop()
                    }
                    word in codeKeywords -> {
                        pushStyle(SpanStyle(color = CodeSyntax.Keyword, fontWeight = FontWeight.SemiBold))
                        append(word)
                        pop()
                    }
                    else -> append(word)
                }
                i = j
                continue
            }
            append(c)
            i++
        }
    }
}

private fun findStringEnd(s: String, start: Int, quote: Char): Int {
    var i = start + 1
    while (i < s.length) {
        if (s[i] == '\\') { i += 2; continue }
        if (s[i] == quote) return i + 1
        i++
    }
    return s.length
}

private val codeKeywords = setOf(
    "fun", "class", "def", "if", "else", "elif", "for", "while", "return", "import", "from",
    "val", "var", "const", "let", "function", "public", "private", "protected", "static",
    "void", "int", "string", "boolean", "async", "await", "new", "this", "null", "true", "false",
    "struct", "impl", "fn", "pub", "use", "type", "interface", "enum", "case", "switch", "break", "continue",
)

/** 过滤面板 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterSheet(
    selectedLanguage: String?,
    onSelectLanguage: (String) -> Unit,
    advancedValues: Map<String, String>,
    expandedFilter: String?,
    onToggleFilter: (String) -> Unit,
    onApplyFilter: (String, String) -> Unit,
    onDismiss: () -> Unit,
) {
    // 显式写白底（主题里也已统一）：手板内部的输入框/加减按钮会跟着换成灰底，
    // 否则「白底套白底」这两个元素会直接看不见
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Primer.BackgroundPrimary,
        dragHandle = { BottomSheetDefaults.DragHandle(color = Primer.Gray300) },
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
        ) {
            Text("筛选", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Primer.TextPrimary)
            Spacer(Modifier.height(12.dp))
            Text("语言", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
            Spacer(Modifier.height(6.dp))
            languages.forEach { (lang, color) ->
                val selected = selectedLanguage == lang
                Row(
                    Modifier.fillMaxWidth().clickable { onSelectLanguage(lang) }.padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(color))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        lang,
                        fontSize = 14.sp,
                        color = if (selected) Primer.Blue500 else Primer.TextPrimary,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    )
                    Spacer(Modifier.weight(1f))
                    if (selected) {
                        Text("✓", color = Primer.Blue500, fontSize = 14.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("高级", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Primer.TextPrimary)
            advancedFilters.forEach { (name, syntax) ->
                val expanded = expandedFilter == name
                val value = advancedValues[name]
                Column {
                    Row(
                        Modifier.fillMaxWidth().clickable { onToggleFilter(name) }.padding(vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        // 手板是白底 → 这个 +/− 圆点要用中性灰垫底才看得见（原来是白色，靠 Material 的
                        // 淡紫容器衬出来；容器改白之后就「消失」了）
                        Box(
                            Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(Primer.Gray150),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(if (expanded) "−" else "+", fontSize = 14.sp, color = Primer.IconSecondary)
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (value != null) "$name：$value" else "$name（$syntax）",
                            fontSize = 13.sp,
                            color = if (value != null) Primer.Blue500 else Primer.TextSecondary,
                        )
                    }
                    if (expanded) {
                        var input by remember(name) { mutableStateOf(value ?: "") }
                        Row(
                            Modifier.fillMaxWidth().padding(start = 28.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            // 同上：输入框在白底手板上要靠灰底 + 描边才成立
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Primer.Gray150)
                                    .border(1.dp, Primer.Border.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp),
                                contentAlignment = Alignment.CenterStart,
                            ) {
                                BasicTextField(
                                    value = input,
                                    onValueChange = { input = it },
                                    singleLine = true,
                                    textStyle = TextStyle(fontSize = 13.sp, color = Primer.TextPrimary),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "应用",
                                fontSize = 13.sp,
                                color = Primer.Blue500,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.clickable { onApplyFilter(name, input) },
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun parseResults(json: String, type: String, me: String): Pair<List<SearchItem>, Long> {
    return runCatching {
        val obj = JSONObject(json)
        val total = obj.optLong("total_count")
        val arr = obj.optJSONArray("items")
        val items = (0 until (arr?.length() ?: 0)).map { i ->
            val it = arr!!.getJSONObject(i)
            when (type) {
                "仓库" -> {
                    // full_name = owner/repo：既是展示标题，也是站内跳转目标
                    val fullName = it.optString("full_name")
                    val pair = ownerRepoOf(fullName)
                    SearchItem(
                        title = fullName,
                        subtitle = it.optString("description").orEmpty(),
                        meta = it.optString("language").takeIf { l -> l.isNotBlank() }
                            ?.let { lang -> "$lang · ${formatCount(it.optLong("stargazers_count"))} 星" },
                        target = pair?.let { (o, r) -> SearchTarget.Repo(o, r) },
                        // 搜索接口不返回 permissions：只能判定「是不是我自己的」
                        relation = pair?.let { (o, _): Pair<String, String> ->
                            repoRelationOf(o, me, isPrivate = it.optBoolean("private", false))
                        },
                    )
                }
                "用户" -> SearchItem(
                    title = it.optString("login"),
                    subtitle = it.optString("html_url").orEmpty(),
                    // 站内没有他人主页，交给浏览器
                    target = SearchTarget.Web(it.optString("html_url")),
                )
                "议题" -> {
                    // repository_url（API 地址）+ number 才是跳转所需信息；html_url 只用于展示
                    val pair = ownerRepoOf(it.optString("repository_url"))
                    val number = it.optLong("number")
                    SearchItem(
                        title = it.optString("title"),
                        subtitle = it.optString("html_url").orEmpty(),
                        meta = it.optString("state"),
                        target = pair?.takeIf { _ -> number > 0 }
                            ?.let { (o, r) -> SearchTarget.Issue(o, r, number) },
                    )
                }
                else -> SearchItem(title = "", subtitle = "")
            }
        }
        items to total
    }.getOrDefault(emptyList<SearchItem>() to 0L)
}

private fun parseCodeResults(json: String): Pair<List<CodeResult>, Long> {
    return runCatching {
        val obj = JSONObject(json)
        val total = obj.optLong("total_count")
        val arr = obj.optJSONArray("items")
        val raw = (0 until (arr?.length() ?: 0)).mapNotNull { i ->
            val it = arr!!.getJSONObject(i)
            val repoObj = it.optJSONObject("repository")
            val repo = repoObj?.optString("full_name") ?: ""
            val owner = repoObj?.optJSONObject("owner")?.optString("login") ?: repo.substringBefore('/')
            val path = it.optString("path")
            val language = repoObj?.optString("language")?.takeIf { l -> l.isNotBlank() }
            val avatarUrl = repoObj?.optJSONObject("owner")?.optString("avatar_url")
            val sha = it.optString("sha").takeIf { s -> s.isNotBlank() }
            val textMatches = it.optJSONArray("text_matches")
            // 选择代码内容的匹配（property 不是 path 的，通常才是代码片段）
            val firstMatch = (0 until (textMatches?.length() ?: 0))
                .map { j -> textMatches!!.getJSONObject(j) }
                .firstOrNull { o -> o.optString("property") != "path" }
                ?: textMatches?.optJSONObject(0)
            val fragment = firstMatch?.optString("fragment") ?: ""
            val matches = firstMatch?.optJSONArray("matches")?.let { m ->
                (0 until m.length()).mapNotNull { j ->
                    val matchObj = m.getJSONObject(j)
                    val text = matchObj.optString("text")
                    val indices = matchObj.optJSONArray("indices")
                    val start = indices?.optInt(0) ?: -1
                    val end = indices?.optInt(1) ?: -1
                    if (start >= 0 && end >= 0) MatchRange(text, start, end) else null
                }
            } ?: emptyList()
            CodeResult(
                owner = owner,
                repository = repo,
                path = path,
                // 代码结果点进去直接落到「文件查看页」（深链接 path）
                target = if (owner.isNotBlank() && repo.isNotBlank() && path.isNotBlank()) {
                    SearchTarget.File(owner, repo, path)
                } else {
                    null
                },
                fileName = path.substringAfterLast('/'),
                avatarUrl = avatarUrl,
                language = language,
                sha = sha,
                fragment = fragment,
                matches = matches,
                matchCount = matches.map { it.text }.distinct().size,
                subPaths = emptyList(),
            )
        }
        // 按 sha 分组：相同内容文件只保留第一个，其余折叠为次级路径（去重）
        val bySha = raw.groupBy { it.sha }
        val items = raw.mapNotNull { item ->
            if (item.sha == null) return@mapNotNull item
            val group = bySha[item.sha].orEmpty()
            val first = group.minByOrNull { it.path }
            if (first != item) return@mapNotNull null
            item.copy(subPaths = group.map { it.path }.filter { it != item.path })
        }
        items to total
    }.getOrDefault(emptyList<CodeResult>() to 0L)
}

private fun parsePullResults(json: String): Pair<List<PullResult>, Long> {
    return runCatching {
        val obj = JSONObject(json)
        val total = obj.optLong("total_count")
        val arr = obj.optJSONArray("items")
        val items = (0 until (arr?.length() ?: 0)).map { i ->
            val it = arr!!.getJSONObject(i)
            val state = it.optString("state")
            val merged = it.optJSONObject("pull_request")?.optString("merged_at")?.isNotBlank() == true
            val repo = it.optString("repository_url").split('/').takeLast(2).joinToString("/")
            PullResult(
                target = ownerRepoOf(it.optString("repository_url"))?.let { (o, r) ->
                    SearchTarget.PullRequest(o, r, it.optLong("number"))
                },
                number = it.optInt("number"),
                title = it.optString("title"),
                state = state,
                merged = merged,
                repository = repo,
            )
        }
        items to total
    }.getOrDefault(emptyList<PullResult>() to 0L)
}

private fun parseCommitResults(json: String): Pair<List<CommitResult>, Long> {
    return runCatching {
        val obj = JSONObject(json)
        val total = obj.optLong("total_count")
        val arr = obj.optJSONArray("items")
        val items = (0 until (arr?.length() ?: 0)).map { i ->
            val it = arr!!.getJSONObject(i)
            val commit = it.optJSONObject("commit")
            val repo = it.optJSONObject("repository")?.optString("full_name") ?: ""
            CommitResult(
                target = ownerRepoOf(repo)?.let { (o, r) ->
                    SearchTarget.Commit(o, r, it.optString("sha"))
                },
                sha = it.optString("sha"),
                message = commit?.optString("message") ?: "",
                author = commit?.optJSONObject("author")?.optString("name")
                    ?: it.optJSONObject("author")?.optString("login") ?: "",
                repository = repo,
            )
        }
        items to total
    }.getOrDefault(emptyList<CommitResult>() to 0L)
}

private fun parseTopicResults(json: String): Pair<List<TopicResult>, Long> {
    return runCatching {
        val obj = JSONObject(json)
        val total = obj.optLong("total_count")
        val arr = obj.optJSONArray("items")
        val items = (0 until (arr?.length() ?: 0)).map { i ->
            val it = arr!!.getJSONObject(i)
            TopicResult(name = it.optString("name"))
        }
        items to total
    }.getOrDefault(emptyList<TopicResult>() to 0L)
}

private fun formatCount(n: Long): String = when {
    n >= 1000 -> "%.1fk".format(n / 1000.0)
    else -> n.toString()
}

private fun langColor(lang: String?): Color = when (lang) {
    "Kotlin" -> Color(0xFFA97BFF)
    "Rust" -> Color(0xFFDEA584)
    "Java" -> Color(0xFFB07219)
    "Python" -> Color(0xFF3572A5)
    "JavaScript" -> Color(0xFFF1E05A)
    "TypeScript" -> Color(0xFF3178C6)
    "Go" -> Color(0xFF00ADD8)
    "Swift" -> Color(0xFFF05138)
    "C++" -> Color(0xFFF34B7D)
    "C" -> Color(0xFF555555)
    "PHP" -> Color(0xFF4F5D95)
    "Markdown" -> Color(0xFF083FA1)
    "Text" -> Color(0xFF8B949E)
    "HTML" -> Color(0xFFE34C26)
    "CSS" -> Color(0xFF663399)
    "Shell" -> Color(0xFF89E051)
    else -> Color(0xFF8B949E)
}

private data class SearchItem(
    val title: String,
    val subtitle: String,
    val meta: String? = null,
    /** 这一行要去哪（解析阶段就定下来，卡片点击直接派发）。 */
    val target: SearchTarget? = null,
    /** 仓库结果专用：与当前账号的关系（我的 / 协作 / 他人）。 */
    val relation: RepoRelation? = null,
)

private data class CodeResult(
    val owner: String,
    val repository: String,
    val path: String,
    val target: SearchTarget? = null,
    val fileName: String,
    val avatarUrl: String? = null,
    val language: String? = null,
    val sha: String? = null,
    val fragment: String,
    val matches: List<MatchRange>,
    val matchCount: Int,
    val subPaths: List<String>,
)

private data class MatchRange(val text: String, val start: Int, val end: Int)

private data class PullResult(
    val number: Int,
    val title: String,
    val state: String,
    val merged: Boolean,
    val repository: String,
    val target: SearchTarget? = null,
)

private data class CommitResult(
    val sha: String,
    val message: String,
    val author: String,
    val repository: String,
    val target: SearchTarget? = null,
)

private data class TopicResult(
    val name: String,
) {
    val target: SearchTarget get() = SearchTarget.Web(topicWebUrl(name))
}

private val types = listOf("代码", "仓库", "议题", "拉取请求", "用户", "提交", "主题")

private val sortOptions = listOf(
    "" to "最佳匹配",
    "stars" to "最多星标",
    "forks" to "最多复刻",
    "updated" to "最近更新",
)

private val languages = listOf(
    "JavaScript" to Color(0xFFF1E05A),
    "Python" to Color(0xFF3572A5),
    "TypeScript" to Color(0xFF3178C6),
    "Java" to Color(0xFFB07219),
    "Kotlin" to Color(0xFFA97BFF),
    "Go" to Color(0xFF00ADD8),
    "Rust" to Color(0xFFDEA584),
    "C++" to Color(0xFFF34B7D),
    "PHP" to Color(0xFF4F5D95),
)

private val advancedFilters = listOf(
    "所有者" to "user:/org:",
    "大小" to "size:",
    "关注者" to "followers:",
    "Fork 数" to "forks:",
    "星标数" to "stars:",
    "创建时间" to "created:",
    "推送时间" to "pushed:",
    "主题" to "topic:",
    "许可证" to "license:",
    "已归档" to "archived:",
    "可见性" to "is:public/private",
)

/**
 * 结果列表底部的分页控件。
 *
 * 三态：
 * - 还有下一页 → 「加载更多（已显示 N / 共 M）」按钮；
 * - 正在加载 → 小转圈 + 「加载中…」；
 * - 已到底（或本页就装下了全部）→ 一行「已到底」灰字，让用户知道不用再下拉。
 */
@Composable
private fun SearchPagingFooter(
    shown: Int,
    total: Long,
    loadingMore: Boolean,
    onLoadMore: () -> Unit,
) {
    Box(
        Modifier.fillMaxWidth().padding(vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        when {
            loadingMore -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = Primer.Blue500,
                    strokeWidth = 2.dp,
                )
                Spacer(Modifier.width(8.dp))
                Text("加载中…", fontSize = 12.5.sp, color = Primer.TextTertiary)
            }

            PagingState(page = 1, total = total, shown = shown).hasMore -> Text(
                loadMoreText(shown, total),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Primer.Blue500,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Primer.InfoSurface)
                    .clickable(onClick = onLoadMore)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )

            else -> Text("已到底", fontSize = 12.sp, color = Primer.TextTertiary)
        }
    }
}
