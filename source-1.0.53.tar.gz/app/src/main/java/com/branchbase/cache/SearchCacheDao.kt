package com.branchbase.cache

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

/**
 * 搜索缓存 DAO。
 */
@Dao
interface SearchCacheDao {

    /** 查询未过期的缓存（同时匹配 type，避免不同类型同 key 互相污染命中结果） */
    @Query("SELECT * FROM search_cache WHERE key = :key AND type = :type AND expireAt > :now")
    suspend fun get(key: String, type: String, now: Long): SearchCacheEntity?

    /**
     * 查询缓存**忽略 TTL**（stale-while-revalidate：先渲染旧数据，再后台刷新）。
     *
     * 与 [get] 的差别只有不过滤 `expireAt`：调用方拿到旧数据后必须触发一次回源，
     * 否则会一直看到过期内容。
     */
    @Query("SELECT * FROM search_cache WHERE key = :key AND type = :type")
    suspend fun getStale(key: String, type: String): SearchCacheEntity?

    /** 插入或替换缓存 */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: SearchCacheEntity)

    /** 删除已过期的缓存 */
    @Query("DELETE FROM search_cache WHERE expireAt <= :now")
    suspend fun deleteExpired(now: Long)

    /** 缓存条目数 */
    @Query("SELECT COUNT(*) FROM search_cache")
    suspend fun count(): Int

    /** 删除最旧的 n 条（LRU 淘汰，按创建时间升序） */
    @Query("DELETE FROM search_cache WHERE key IN (SELECT key FROM search_cache ORDER BY createdAt ASC LIMIT :n)")
    suspend fun deleteOldest(n: Int)

    /** 删除指定 key 的缓存（bypass：强制刷新时清除） */
    @Query("DELETE FROM search_cache WHERE key = :key")
    suspend fun delete(key: String)
}