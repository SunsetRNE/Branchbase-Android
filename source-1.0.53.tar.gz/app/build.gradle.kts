import com.android.build.api.variant.impl.VariantOutputImpl
import java.io.File
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Base64
import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// 从 local.properties 读取 client secret（本地私有，不进 git）
val localProps = Properties()
val localPropsFile = rootProject.file("local.properties")
if (localPropsFile.exists()) {
    localPropsFile.inputStream().use { localProps.load(it) }
}
val branchbaseClientSecret = localProps.getProperty("branchbase.client.secret") ?: ""
val githubRedirectUri = localProps.getProperty("github.redirect.uri") ?: "branchbase://oauth/callback"

// ── 版本号标准化 ──
// 工程版本号（version.properties，手动维护）
val versionProps = Properties()
val versionPropsFile = rootProject.file("version.properties")
if (versionPropsFile.exists()) {
    versionPropsFile.inputStream().use { versionProps.load(it) }
}
val engineeringVersion = versionProps.getProperty("versionName") ?: "1.0.0"
val engineeringVersionCode = (versionProps.getProperty("versionCode") ?: "1").toIntOrNull() ?: 1

// 构建时间（年月日-时分，固定 Asia/Shanghai 时区，避免本地与 CI 时区差异）
// 优先读取 tools/build/assemble.sh 注入的环境变量，保证跨阶段版本参数一致
fun buildTimestamp(): String =
    System.getenv("BRANCHBASE_BUILD_TIME") ?: LocalDateTime.now(ZoneId.of("Asia/Shanghai"))
        .format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmm"))

// 七位 git 哈希。
//
// 配置缓存兼容性：配置阶段**不能启动外部进程**（ProcessBuilder 会让
// `org.gradle.configuration-cache=true` 直接失败）。CI 与本地构建脚本
// （tools/build/assemble.sh）都会注入 BRANCHBASE_GIT_HASH；
// 直接从 IDE 构建时退化为 unknown —— 只影响 BuildConfig 的展示值。
fun gitShortHash(): String =
    System.getenv("BRANCHBASE_GIT_HASH")?.takeIf { it.isNotBlank() } ?: "unknown"

val buildTime = buildTimestamp()
val gitHash = gitShortHash()
// 标准版本号 = 工程版本号-年月日-时分-七位哈希
val standardVersion = "$engineeringVersion-$buildTime-$gitHash"

// ── Release 签名（从 CI Secrets 环境变量注入） ──
val releaseKeystoreBase64 = System.getenv("KEYSTORE_BASE64")
val releaseStorePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
val releaseKeyAlias = System.getenv("KEY_ALIAS") ?: ""
val releaseKeyPassword = System.getenv("KEY_PASSWORD") ?: ""

// 解码 base64 keystore 到临时文件（仅当 CI 提供 KEYSTORE_BASE64 时生效）
val releaseKeystoreFile: File? = releaseKeystoreBase64?.let { b64 ->
    val f = File(rootProject.layout.buildDirectory.get().asFile, "release.keystore")
    f.parentFile?.mkdirs()
    f.writeBytes(Base64.getDecoder().decode(b64))
    f
}

android {
    namespace = "com.branchbase"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.branchbase"
        minSdk = 24
        targetSdk = 35
        versionCode = engineeringVersionCode
        versionName = standardVersion

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        // 注入 client secret（来自 local.properties，不硬编码）
        buildConfigField("String", "BRANCHBASE_CLIENT_SECRET", "\"$branchbaseClientSecret\"")
        // 注入 redirect_uri（来自 local.properties，便于调试时调整）
        buildConfigField("String", "GITHUB_REDIRECT_URI", "\"$githubRedirectUri\"")
        // 注入版本号（工程版本号 + 标准版本号 + 构建时间 + 七位哈希）
        buildConfigField("String", "ENGINEERING_VERSION", "\"$engineeringVersion\"")
        buildConfigField("String", "STANDARD_VERSION", "\"$standardVersion\"")
        buildConfigField("String", "BUILD_TIME", "\"$buildTime\"")
        buildConfigField("String", "GIT_HASH", "\"$gitHash\"")
    }

    signingConfigs {
        // 固定 debug 签名（入库），确保本地与 CI 的 Beta 签名一致，可覆盖安装
        create("beta") {
            storeFile = rootProject.file("app/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        // Release 签名（从 CI Secrets 注入，仅在提供 KEYSTORE_BASE64 时生效）
        if (releaseKeystoreFile != null) {
            create("release") {
                storeFile = releaseKeystoreFile
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        /**
         * 慢帧日志（`FrameWatch`）的**编译通道默认值**。
         *
         * 需求：正式编译（`build-release.yml` → `assembleRelease`）**默认关闭**，
         * Beta（`build-beta.yml` → `assembleDebug` / `assemblePerfBeta`）**默认开启**。
         *
         * 为什么按通道分：慢帧日志是**诊断仪表**，会给日志文件持续增量，正式版用户不该
         * 无缘无故多出一份常年写入的文件；而 Beta 的全部意义就是拿来测。运行时开关
         * （设置 → 关于与诊断 → 慢帧日志）永远保留，所以正式版用户可以临时打开来抓一次。
         */
        debug {
            signingConfig = signingConfigs.getByName("beta")
            // Beta 版：标准版本号尾部附加 "-Beta"
            versionNameSuffix = "-Beta"
            buildConfigField("boolean", "FRAME_WATCH_DEFAULT", "true")
        }
        release {
            if (releaseKeystoreFile != null) {
                signingConfig = signingConfigs.getByName("release")
            }
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            buildConfigField("boolean", "FRAME_WATCH_DEFAULT", "false")
        }
        /**
         * 性能测试版：**release 的性能特征 + beta 的签名**。
         *
         * 为什么需要它 —— 在此之前想评一次动效/滚动性能只能二选一：
         * - beta（`assembleDebug` + 入库的 beta 钥匙）：能覆盖安装，但 `isDebuggable=true`
         *   → ART 几乎不做 AOT、也拿不到依赖自带的 baseline profile，**测出来的不是真实性能**；
         * - 正式版（`assembleRelease` + CI secrets 里的 release 钥匙）：性能真实，
         *   但签名与 beta 不同 → **必须卸载才能装**，登录态与缓存全清，首轮都是冷缓存，
         *   同样没法做「改前 / 改后」对比。
         *
         * 这个变体取两者交集：`initWith(release)` 拿到 `isDebuggable=false`（ART 才愿意 AOT、
         * AGP 才会把 baseline profile 合进 APK），签名却沿用入库的固定 beta 钥匙 —— 覆盖安装即可。
         */
        create("perfBeta") {
            initWith(getByName("release"))
            // ⚠️ 必须在 initWith 之后覆盖：release 的 signingConfig 与 buildConfigField 会被一起复制过来
            signingConfig = signingConfigs.getByName("beta")
            versionNameSuffix = "-Beta"
            isMinifyEnabled = false
            // 性能测试版属于 Beta 通道：慢帧日志默认开启（见 buildTypes 顶部的说明）
            buildConfigField("boolean", "FRAME_WATCH_DEFAULT", "true")
            // 依赖的 library 模块只有 debug/release 两套变体，这里指回去
            matchingFallbacks += listOf("release")
        }
    }
    compileOptions {
        // Sora Editor 的 language-textmate 要求 app 启用 core library desugaring
        // （AAR 元数据检查会拦下来，见 :app:checkDebugAarMetadata）
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

// APK 输出文件名：Branchbase-工程版本号-年月日-时分-七位哈希[-debug|-perfBeta].apk
// 例：Branchbase-1.0.3-20260902-2226-a1b2c3d-debug.apk / Branchbase-1.0.3-20260902-2226-a1b2c3d.apk
androidComponents {
    onVariants { variant ->
        variant.outputs.forEach { output ->
            // 各个变体要在 dist/ 里能分辨：release 不带后缀，其余带自己的变体名
            val suffix = when (variant.buildType) {
                "debug" -> "-debug"
                "perfBeta" -> "-perfBeta"
                else -> ""
            }
            (output as VariantOutputImpl).outputFileName.set("Branchbase-${standardVersion}${suffix}.apk")
        }
    }
}

// Force use of ARM64 binaries for AAPT2 in Proot environment
configurations.all {
    resolutionStrategy.eachDependency {
        if (requested.group == "com.android.tools.build" && requested.name == "aapt2") {
            useTarget("com.android.tools.build:aapt2:${'$'}{requested.version}:linux-aarch64")
        }
    }
}

dependencies {

    // 代码编辑器独立模块（封装 Sora Editor）—— 换库 / 升级 / 移除只动 :editor
    implementation(project(":editor"))

    // 沉浸式翻译独立模块（设置 / 分片 / 占位符保护 / 缓存 / 调度 / 页面脚本）
    // :app 只提供后端实现（RustTranslateEngine）并在 Application 里 install 一次
    implementation(project(":translate"))

    // 内建下载独立模块（下载引擎 / 前台服务 / 通知进度 / 通知权限 / 安装与打开文件）
    // :app 只注入凭据与小图标（DownloaderRuntime.install 一行）
    implementation(project(":downloader"))

    // 图片查看器独立模块（正文页点图放大：双指缩放 / 双击 / 下拉关闭）
    implementation(project(":imageviewer"))

    // 作业日志独立模块（取数单飞合并 / 分组切段 / 内存与磁盘缓存）
    // :app 只注入日志来源（RustBridge）与缓存适配（PageCache），见 JobLogWiring.kt
    implementation(project(":joblogs"))

    // core library desugaring：Sora Editor 的 language-textmate 要求
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.coil.compose)
    implementation(libs.coil.svg)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    testImplementation(libs.junit)
    // JVM 单测里 android.jar 的 org.json 是空壳（方法抛 not mocked），补真实实现
    testImplementation(libs.org.json)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}
